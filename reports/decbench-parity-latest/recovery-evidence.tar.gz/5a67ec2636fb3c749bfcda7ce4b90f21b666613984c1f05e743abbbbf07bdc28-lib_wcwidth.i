# 0 "wchar/lib_wcwidth.c"
# 1 "/tmp/tmpg1w5kvms/nuttx/libs/libc//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "wchar/lib_wcwidth.c"
# 32 "wchar/lib_wcwidth.c"
# 1 "/tmp/tmpg1w5kvms/nuttx/include/wchar.h" 1 3 4
# 37 "/tmp/tmpg1w5kvms/nuttx/include/wchar.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 1 3 4
# 30 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/config.h" 1 3 4
# 31 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 1 3 4
# 31 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/compiler.h" 1 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 2 3 4


# 1 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 1 3 4
# 36 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/types.h" 1 3 4
# 55 "/tmp/tmpg1w5kvms/nuttx/include/arch/types.h" 3 4

# 55 "/tmp/tmpg1w5kvms/nuttx/include/arch/types.h" 3 4
typedef signed char _int8_t;
typedef unsigned char _uint8_t;

typedef signed short _int16_t;
typedef unsigned short _uint16_t;


typedef long int _int32_t;

typedef long unsigned int _uint32_t;
# 73 "/tmp/tmpg1w5kvms/nuttx/include/arch/types.h" 3 4
typedef signed long long _int64_t;
typedef unsigned long long _uint64_t;


typedef _int64_t _intmax_t;
typedef _uint64_t _uintmax_t;


typedef unsigned int _wchar_t;




typedef int _wint_t;
typedef int _wctype_t;
# 98 "/tmp/tmpg1w5kvms/nuttx/include/arch/types.h" 3 4
typedef signed int _ssize_t;

typedef unsigned int _size_t;
# 116 "/tmp/tmpg1w5kvms/nuttx/include/arch/types.h" 3 4
typedef unsigned char irqstate_t;
# 37 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/inttypes.h" 1 3 4
# 38 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/limits.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/limits.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/limits.h" 1 3 4
# 35 "/tmp/tmpg1w5kvms/nuttx/include/limits.h" 2 3 4
# 39 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 2 3 4
# 169 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 3 4
typedef _int8_t int8_t;
typedef _uint8_t uint8_t;

typedef _int16_t int16_t;
typedef _uint16_t uint16_t;






typedef _int32_t int32_t;
typedef _uint32_t uint32_t;


typedef _int64_t int64_t;
typedef _uint64_t uint64_t;




typedef _int8_t int_least8_t;
typedef _uint8_t uint_least8_t;

typedef _int16_t int_least16_t;
typedef _uint16_t uint_least16_t;





typedef _int32_t int_least24_t;
typedef _uint32_t uint_least24_t;


typedef _int32_t int_least32_t;
typedef _uint32_t uint_least32_t;


typedef _int64_t int_least64_t;
typedef _uint64_t uint_least64_t;




typedef _int8_t int_fast8_t;
typedef _uint8_t uint_fast8_t;

typedef int int_fast16_t;
typedef unsigned int uint_fast16_t;





typedef _int32_t int_fast24_t;
typedef _uint32_t uint_fast24_t;


typedef _int32_t int_fast32_t;
typedef _uint32_t uint_fast32_t;


typedef _int64_t int_fast64_t;
typedef _uint64_t uint_fast64_t;
# 242 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 3 4
typedef _ssize_t intptr_t;
typedef _size_t uintptr_t;
# 256 "/tmp/tmpg1w5kvms/nuttx/include/stdint.h" 3 4
typedef _intmax_t intmax_t;
typedef _uintmax_t uintmax_t;
# 35 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 2 3 4
# 110 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
typedef unsigned int mode_t;
# 135 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
typedef _size_t size_t;
typedef _ssize_t ssize_t;
typedef _size_t rsize_t;





typedef unsigned int uid_t;
typedef unsigned int gid_t;





typedef uint32_t dev_t;



typedef uint16_t ino_t;



typedef uint16_t nlink_t;





typedef int pid_t;





typedef int id_t;






typedef int32_t key_t;



typedef intptr_t ptrdiff_t;
# 190 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
typedef _wchar_t wchar_t;






typedef _wint_t wint_t;






typedef _wctype_t wctype_t;
# 218 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
typedef uint32_t fsblkcnt_t;
typedef uint32_t fsfilcnt_t;
# 230 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
typedef uint32_t blkcnt_t;
typedef int32_t off_t;
typedef int32_t fpos_t;


typedef off_t loff_t;



typedef int16_t blksize_t;



typedef unsigned int socklen_t;

typedef uint16_t sa_family_t;
# 258 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
typedef uint32_t clock_t;
typedef uint32_t time_t;

typedef int clockid_t;
typedef void *timer_t;







typedef uint32_t useconds_t;
typedef int32_t suseconds_t;




typedef volatile uint32_t cpu_set_t;






typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;



typedef unsigned char unchar;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef signed char s_char;
typedef char *caddr_t;



typedef uint8_t u_int8_t;
typedef uint16_t u_int16_t;
typedef uint32_t u_int32_t;




typedef uint64_t u_int64_t;


struct fsid_s
{
  int val[2];
};



typedef int (*main_t)(int argc, char *argv[]);







enum
{
  ERROR = -1,
  OK = 0
};


struct pthread_attr_s;
typedef struct pthread_attr_s pthread_attr_t;




struct pthread_cond_s;
typedef struct pthread_cond_s pthread_cond_t;




typedef struct pthread_condattr_s pthread_condattr_t;




typedef int pthread_key_t;




struct pthread_mutex_s;
typedef struct pthread_mutex_s pthread_mutex_t;




struct pthread_mutexattr_s;
typedef struct pthread_mutexattr_s pthread_mutexattr_t;




typedef pid_t pthread_t;




struct pthread_once_s;
typedef struct pthread_once_s pthread_once_t;
# 390 "/tmp/tmpg1w5kvms/nuttx/include/sys/types.h" 3 4
int nsh_main(int argc, char *argv[]);
# 33 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 2 3 4
# 1 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 103 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdarg.h" 3 4
typedef __gnuc_va_list va_list;
# 34 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/time.h" 1 3 4
# 115 "/tmp/tmpg1w5kvms/nuttx/include/time.h" 3 4
struct timespec
{
  time_t tv_sec;
  long tv_nsec;
};
# 130 "/tmp/tmpg1w5kvms/nuttx/include/time.h" 3 4
struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;
  long tm_gmtoff;
  const char *tm_zone;
};



struct itimerspec
{
  struct timespec it_interval;
  struct timespec it_value;
};



struct sigevent;
# 191 "/tmp/tmpg1w5kvms/nuttx/include/time.h" 3 4
clock_t clock(void);

int clock_settime(clockid_t clockid, const struct timespec *tp);
int clock_gettime(clockid_t clockid, struct timespec *tp);
int clock_getres(clockid_t clockid, struct timespec *res);
int clock_getcpuclockid(pid_t pid, clockid_t *clockid);
int timespec_get( struct timespec *t, int b);

time_t timegm( struct tm *tp);
time_t mktime( struct tm *tp);

 struct tm *gmtime( const time_t *timep);
 struct tm *gmtime_r( const time_t *timep, struct tm *result);

 struct tm *localtime( const time_t *timep);
 struct tm *localtime_r( const time_t *timep, struct tm *result);

size_t strftime( char *s, size_t max, const char *format,
                const struct tm *tm) __attribute__((__format__(__strftime__, 3, 0)));
 char *strptime( const char *s, const char *format,
                   struct tm *tm);

 char *asctime( const struct tm *tp);
 char *asctime_r( const struct tm *tp, char *buf);
 char *ctime( const time_t *timep);
 char *ctime_r( const time_t *timep, char *buf);

time_t time( time_t *timep);


double difftime(time_t time1, time_t time0);




int timer_create(clockid_t clockid, struct sigevent *evp,
                 timer_t *timerid);
int timer_delete(timer_t timerid);
int timer_settime(timer_t timerid, int flags,
                  const struct itimerspec *value,
                  struct itimerspec *ovalue);
int timer_gettime(timer_t timerid, struct itimerspec *value);
int timer_getoverrun(timer_t timerid);

int clock_nanosleep(clockid_t clockid, int flags,
                    const struct timespec *rqtp,
                    struct timespec *rmtp);
int nanosleep( const struct timespec *rqtp, struct timespec *rmtp);
# 35 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 1 3 4
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 1 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/stdbool.h" 1 3 4
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 2 3 4
# 144 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/serial/tioctl.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/serial/tioctl.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 1 3 4
# 35 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/serial/tioctl.h" 2 3 4
# 209 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/serial/tioctl.h" 3 4
struct winsize
{
  uint16_t ws_row;
  uint16_t ws_col;

  uint16_t ws_xpixel;
  uint16_t ws_ypixel;
};



struct serial_rs485
{
  uint32_t flags;
  uint32_t delay_rts_before_send;
  uint32_t delay_rts_after_send;
};
# 145 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 2 3 4
# 814 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/ioctl.h" 3 4
struct geometry
{
  _Bool geo_available;
  _Bool geo_mediachanged;
  _Bool geo_writeenabled;
  blkcnt_t geo_nsectors;
  blksize_t geo_sectorsize;



  char geo_model[32 + 1];
};

struct partition_info_s
{
  size_t numsectors;
  size_t sectorsize;
  off_t startsector;






  char parent[32 + 1];
};

struct pipe_peek_s
{
  void *buf;
  size_t offset;
  size_t size;
};
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/uio.h" 1 3 4
# 44 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/uio.h" 3 4
struct uio
{
  const struct iovec *uio_iov;
  int uio_iovcnt;
  size_t uio_resid;
  size_t uio_offset_in_iov;




};
# 68 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/uio.h" 3 4
void uio_advance( struct uio *uio, size_t sz);
# 85 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/uio.h" 3 4
int uio_init( struct uio *uio, const struct iovec *iov, int iovcnt);
# 95 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/uio.h" 3 4
void uio_copyfrom( struct uio *uio, size_t offset, const void *buf,
                  size_t len);
# 106 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/uio.h" 3 4
void uio_copyto( struct uio *uio, size_t offset, void *buf,
                size_t len);
# 35 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/sys/uio.h" 1 3 4
# 61 "/tmp/tmpg1w5kvms/nuttx/include/sys/uio.h" 3 4
struct iovec
{
  void *iov_base;
  size_t iov_len;
};
# 116 "/tmp/tmpg1w5kvms/nuttx/include/sys/uio.h" 3 4
ssize_t readv(int fildes, const struct iovec *iov, int iovcnt);
# 158 "/tmp/tmpg1w5kvms/nuttx/include/sys/uio.h" 3 4
ssize_t writev(int fildes, const struct iovec *iov, int iovcnt);

ssize_t preadv(int fildes, const struct iovec *iov, int iovcnt,
               off_t offset);

ssize_t pwritev(int fildes, const struct iovec *iov, int iovcnt,
                off_t offset);
# 37 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4






# 1 "/tmp/tmpg1w5kvms/nuttx/include/dirent.h" 1 3 4
# 113 "/tmp/tmpg1w5kvms/nuttx/include/dirent.h" 3 4
struct dirent
{
  uint8_t d_type;
  char d_name[32 + 1];
};

typedef struct
{
  int fd;
  struct dirent entry;
} DIR;
# 144 "/tmp/tmpg1w5kvms/nuttx/include/dirent.h" 3 4
int closedir( DIR *dirp);
 DIR *opendir( const char *path);
 DIR *fdopendir(int fd);
 struct dirent *readdir( DIR *dirp);
int readdir_r( DIR *dirp, struct dirent *entry,
                     struct dirent **result);
void rewinddir( DIR *dirp);
void seekdir( DIR *dirp, off_t loc);
off_t telldir( DIR *dirp);
int scandir( const char *path, struct dirent ***namelist,
                   int (*filter)( const struct dirent *),
                   int (*compar)( const struct dirent **,
                                      const struct dirent **));
int alphasort( const struct dirent **a,
                     const struct dirent **b);
int versionsort( const struct dirent **a,
                       const struct dirent **b);

int dirfd( DIR *dirp);
# 44 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/atomic.h" 1 3 4
# 67 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/atomic.h" 3 4
# 1 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdatomic.h" 1 3 4
# 29 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdatomic.h" 3 4
typedef enum
  {
    memory_order_relaxed = 0,
    memory_order_consume = 1,
    memory_order_acquire = 2,
    memory_order_release = 3,
    memory_order_acq_rel = 4,
    memory_order_seq_cst = 5
  } memory_order;


typedef _Atomic _Bool atomic_bool;
typedef _Atomic char atomic_char;
typedef _Atomic signed char atomic_schar;
typedef _Atomic unsigned char atomic_uchar;
typedef _Atomic short atomic_short;
typedef _Atomic unsigned short atomic_ushort;
typedef _Atomic int atomic_int;
typedef _Atomic unsigned int atomic_uint;
typedef _Atomic long atomic_long;
typedef _Atomic unsigned long atomic_ulong;
typedef _Atomic long long atomic_llong;
typedef _Atomic unsigned long long atomic_ullong;



typedef _Atomic short unsigned int atomic_char16_t;
typedef _Atomic long unsigned int atomic_char32_t;
typedef _Atomic unsigned int atomic_wchar_t;
typedef _Atomic signed char atomic_int_least8_t;
typedef _Atomic unsigned char atomic_uint_least8_t;
typedef _Atomic short int atomic_int_least16_t;
typedef _Atomic short unsigned int atomic_uint_least16_t;
typedef _Atomic long int atomic_int_least32_t;
typedef _Atomic long unsigned int atomic_uint_least32_t;
typedef _Atomic long long int atomic_int_least64_t;
typedef _Atomic long long unsigned int atomic_uint_least64_t;
typedef _Atomic int atomic_int_fast8_t;
typedef _Atomic unsigned int atomic_uint_fast8_t;
typedef _Atomic int atomic_int_fast16_t;
typedef _Atomic unsigned int atomic_uint_fast16_t;
typedef _Atomic int atomic_int_fast32_t;
typedef _Atomic unsigned int atomic_uint_fast32_t;
typedef _Atomic long long int atomic_int_fast64_t;
typedef _Atomic long long unsigned int atomic_uint_fast64_t;
typedef _Atomic int atomic_intptr_t;
typedef _Atomic unsigned int atomic_uintptr_t;
typedef _Atomic unsigned int atomic_size_t;
typedef _Atomic int atomic_ptrdiff_t;
typedef _Atomic long long int atomic_intmax_t;
typedef _Atomic long long unsigned int atomic_uintmax_t;
# 97 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdatomic.h" 3 4
extern void atomic_thread_fence (memory_order);

extern void atomic_signal_fence (memory_order);
# 226 "/usr/lib/gcc/arm-none-eabi/13.2.1/include/stdatomic.h" 3 4
typedef _Atomic struct
{

  _Bool __val;



} atomic_flag;




extern _Bool atomic_flag_test_and_set (volatile atomic_flag *);


extern _Bool atomic_flag_test_and_set_explicit (volatile atomic_flag *,
      memory_order);



extern void atomic_flag_clear (volatile atomic_flag *);

extern void atomic_flag_clear_explicit (volatile atomic_flag *, memory_order);
# 68 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/atomic.h" 2 3 4







typedef volatile _Atomic int32_t atomic_t;
typedef volatile _Atomic int64_t atomic64_t;
# 225 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/atomic.h" 3 4
void nx_atomic_store_4( volatile void *ptr, int32_t value, int memorder);
void nx_atomic_store_8( volatile void *ptr, int64_t value, int memorder);
int32_t nx_atomic_load_4( const volatile void *ptr, int memorder);
int64_t nx_atomic_load_8( const volatile void *ptr, int memorder);
int32_t nx_atomic_exchange_4( volatile void *ptr, int32_t value,
                             int memorder);
int64_t nx_atomic_exchange_8( volatile void *ptr, int64_t value,
                             int memorder);
_Bool nx_atomic_compare_exchange_4( volatile void *ptr, void *expect,
                                  int32_t desired, _Bool weak,
                                  int success, int failure);
_Bool nx_atomic_compare_exchange_8( volatile void *ptr, void *expect,
                                  int64_t desired, _Bool weak,
                                  int success, int failure);
int32_t nx_atomic_fetch_add_4( volatile void *ptr, int32_t value,
                              int memorder);
int64_t nx_atomic_fetch_add_8( volatile void *ptr, int64_t value,
                              int memorder);
int32_t nx_atomic_fetch_sub_4( volatile void *ptr, int32_t value,
                              int memorder);
int64_t nx_atomic_fetch_sub_8( volatile void *ptr, int64_t value,
                              int memorder);
int32_t nx_atomic_fetch_and_4( volatile void *ptr, int32_t value,
                              int memorder);
int64_t nx_atomic_fetch_and_8( volatile void *ptr, int64_t value,
                              int memorder);
int32_t nx_atomic_fetch_or_4( volatile void *ptr, int32_t value,
                             int memorder);
int64_t nx_atomic_fetch_or_8( volatile void *ptr, int64_t value,
                             int memorder);
int32_t nx_atomic_fetch_xor_4( volatile void *ptr, int32_t value,
                              int memorder);
int64_t nx_atomic_fetch_xor_8( volatile void *ptr, int64_t value,
                              int memorder);
# 46 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 1 3 4
# 30 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/assert.h" 1 3 4
# 186 "/tmp/tmpg1w5kvms/nuttx/include/assert.h" 3 4
void _assert( const char *filename, int linenum,
             const char *msg, void *regs);
# 197 "/tmp/tmpg1w5kvms/nuttx/include/assert.h" 3 4
void __assert( const char *filename, int linenum,
              const char *msg) __attribute__((noreturn));
# 31 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 2 3 4


# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 1 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/errno.h" 1 3 4
# 366 "/tmp/tmpg1w5kvms/nuttx/include/errno.h" 3 4
 int *__errno(void);
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 1 3 4
# 35 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/queue.h" 1 3 4
# 322 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/queue.h" 3 4
struct sq_entry_s
{
  struct sq_entry_s *flink;
};
typedef struct sq_entry_s sq_entry_t;

struct dq_entry_s
{
  struct dq_entry_s *flink;
  struct dq_entry_s *blink;
};
typedef struct dq_entry_s dq_entry_t;

struct sq_queue_s
{
  sq_entry_t *head;
  sq_entry_t *tail;
};
typedef struct sq_queue_s sq_queue_t;

struct dq_queue_s
{
  dq_entry_t *head;
  dq_entry_t *tail;
};
typedef struct dq_queue_s dq_queue_t;
# 367 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/queue.h" 3 4
static __attribute__((always_inline)) inline void sq_addafter( sq_entry_t *prev, sq_entry_t *node,
                               sq_queue_t *queue)
{
  if (!queue->head || prev == queue->tail)
    {
      do { sq_entry_t *tmp_node = (node); tmp_node->flink = ((void*)0); if (!(queue)->head) { (queue)->head = tmp_node; (queue)->tail = tmp_node; } else { (queue)->tail->flink = tmp_node; (queue)->tail = tmp_node; } } while (0);
    }
  else
    {
      node->flink = prev->flink;
      prev->flink = node;
    }
}






static __attribute__((always_inline)) inline void dq_addafter( dq_entry_t *prev, dq_entry_t *node,
                               dq_queue_t *queue)
{
  if (!queue->head || prev == queue->tail)
    {
      do { dq_entry_t *tmp_node = (node); tmp_node->flink = ((void*)0); tmp_node->blink = (queue)->tail; if (!(queue)->head) { (queue)->head = tmp_node; (queue)->tail = tmp_node; } else { (queue)->tail->flink = tmp_node; (queue)->tail = tmp_node; } } while (0);
    }
  else
    {
      dq_entry_t *next = prev->flink;
      node->blink = prev;
      node->flink = next;
      next->blink = node;
      prev->flink = node;
    }
}







static __attribute__((always_inline)) inline sq_entry_t *sq_remafter( sq_entry_t *node,
                                          sq_queue_t *queue)
{
  sq_entry_t *ret = node->flink;

  if (queue->head && ret)
    {
      if (queue->tail == ret)
        {
          queue->tail = node;
          node->flink = ((void*)0);
        }
      else
        {
          node->flink = ret->flink;
        }

      ret->flink = ((void*)0);
    }

  return ret;
}





static __attribute__((always_inline)) inline dq_entry_t *dq_remafter( dq_entry_t *node,
                                          dq_queue_t *queue)
{
  dq_entry_t *ret = node->flink;

  if (queue->head != ((void*)0) && ret != ((void*)0))
    {
      do { dq_entry_t *tmp_node = (ret); dq_entry_t *tmp_prev = tmp_node->blink; dq_entry_t *tmp_next = tmp_node->flink; if (!tmp_prev) { (queue)->head = tmp_next; } else { tmp_prev->flink = tmp_next; } if (!tmp_next) { (queue)->tail = tmp_prev; } else { tmp_next->blink = tmp_prev; } tmp_node->flink = ((void*)0); tmp_node->blink = ((void*)0); } while (0);
    }

  return ret;
}





static __attribute__((always_inline)) inline sq_entry_t *sq_remlast( sq_queue_t *queue)
{
  sq_entry_t *ret = queue->tail;

  if (ret)
    {
      if (queue->head == queue->tail)
        {
          queue->head = ((void*)0);
          queue->tail = ((void*)0);
        }
      else
        {
          sq_entry_t *prev;
          for (prev = queue->head;
              prev && prev->flink != ret;
              prev = prev->flink);

          if (prev)
            {
              prev->flink = ((void*)0);
              queue->tail = prev;
            }
        }

      ret->flink = ((void*)0);
    }

  return ret;
}





static __attribute__((always_inline)) inline dq_entry_t *dq_remlast( dq_queue_t *queue)
{
  dq_entry_t *ret = queue->tail;

  if (ret)
    {
      dq_entry_t *prev = ret->blink;
      if (!prev)
        {
          queue->head = ((void*)0);
          queue->tail = ((void*)0);
        }
      else
        {
          queue->tail = prev;
          prev->flink = ((void*)0);
        }

      ret->flink = ((void*)0);
      ret->blink = ((void*)0);
    }

  return ret;
}





static __attribute__((always_inline)) inline sq_entry_t *sq_remfirst( sq_queue_t *queue)
{
  sq_entry_t *ret = queue->head;

  if (ret)
    {
      queue->head = ret->flink;
      if (!queue->head)
        {
          queue->tail = ((void*)0);
        }

      ret->flink = ((void*)0);
    }

  return ret;
}





static __attribute__((always_inline)) inline dq_entry_t *dq_remfirst( dq_queue_t *queue)
{
  dq_entry_t *ret = queue->head;

  if (ret)
    {
      dq_entry_t *next = ret->flink;
      if (!next)
        {
          queue->head = ((void*)0);
          queue->tail = ((void*)0);
        }
      else
        {
          queue->head = next;
          next->blink = ((void*)0);
        }

      ret->flink = ((void*)0);
      ret->blink = ((void*)0);
    }

  return ret;
}







static __attribute__((always_inline)) inline size_t sq_count( sq_queue_t *queue)
{
  sq_entry_t *node;
  size_t count;

  for (node = queue->head, count = 0;
       node != ((void*)0);
       node = node->flink, count++);

  return count;
}





static __attribute__((always_inline)) inline size_t dq_count( dq_queue_t *queue)
{
  dq_entry_t *node;
  size_t count;

  for (node = queue->head, count = 0;
       node != ((void*)0);
       node = node->flink, count++);

  return count;
}
# 36 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 2 3 4
# 105 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 3 4
struct sem_s
{
  union
    {
      volatile int32_t semcount;

      volatile uint32_t mholder;




    } val;





  uint8_t flags;

  dq_queue_t waitlist;
# 141 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 3 4
};

typedef struct sem_s sem_t;
# 186 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 3 4
int sem_init( sem_t *sem, int pshared, unsigned int value);
int sem_destroy( sem_t *sem);
int sem_wait( sem_t *sem);
int sem_timedwait( sem_t *sem, const struct timespec *abstime);
int sem_clockwait( sem_t *sem, clockid_t clockid,
                         const struct timespec *abstime);
int sem_trywait( sem_t *sem);
int sem_post( sem_t *sem);
int sem_getvalue( sem_t *sem, int *sval);
# 239 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 3 4
int sem_setprotocol( sem_t *sem, int protocol);
# 260 "/tmp/tmpg1w5kvms/nuttx/include/semaphore.h" 3 4
int sem_getprotocol( sem_t *sem, int *protocol);
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 1 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/sys/timex.h" 1 3 4
# 30 "/tmp/tmpg1w5kvms/nuttx/include/sys/timex.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 1 3 4
# 33 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/signal.h" 1 3 4
# 320 "/tmp/tmpg1w5kvms/nuttx/include/signal.h" 3 4
struct sigset_s
{
  uint32_t _elem[(((63 + 1) + 31) >> 5)];
};

typedef struct sigset_s sigset_t;





typedef volatile int sig_atomic_t;



union sigval
{
  int sival_int;
  void *sival_ptr;
};






typedef void (*sigev_notify_function_t)(union sigval value);

typedef struct sigevent
{
  int sigev_notify;
  int sigev_signo;
  union sigval sigev_value;

  union
    {
# 368 "/tmp/tmpg1w5kvms/nuttx/include/signal.h" 3 4
      pid_t _tid;
    } _sigev_un;
} sigevent_t;







struct siginfo
{
  uint8_t si_signo;
  uint8_t si_code;
  uint8_t si_errno;
  union sigval si_value;







  void *si_user;
};

typedef struct siginfo siginfo_t;





typedef void (*_sa_handler_t)(int signo);
typedef void (*_sa_sigaction_t)(int signo, siginfo_t *siginfo,
                                     void *context);



typedef _sa_handler_t sighandler_t;



struct sigaction
{
  union
  {
    _sa_handler_t _sa_handler;
    _sa_sigaction_t _sa_sigaction;
  } sa_u;
  sigset_t sa_mask;
  int sa_flags;
  union
  {
    void (*sa_restorer)(void);
    void *sa_user;
  };
};
# 433 "/tmp/tmpg1w5kvms/nuttx/include/signal.h" 3 4
typedef struct
{
  void *ss_sp;
  int ss_flags;
  size_t ss_size;
} stack_t;

typedef void (*sig_t)(int);
# 454 "/tmp/tmpg1w5kvms/nuttx/include/signal.h" 3 4
int kill(pid_t pid, int signo);
int killpg(pid_t pgrp, int signo);
int tgkill(pid_t pid, pid_t tid, int signo);
void psignal(int signum, const char *message);
void psiginfo( const siginfo_t *pinfo, const char *message);
int raise(int signo);
int sigaction(int signo, const struct sigaction *act,
               struct sigaction *oact);
int sigaddset( sigset_t *set, int signo);
int sigandset( sigset_t *dest, const sigset_t *left,
               const sigset_t *right);
int sigdelset( sigset_t *set, int signo);
int sigemptyset( sigset_t *set);
int sigfillset( sigset_t *set);
int sighold(int signo);
int sigisemptyset( sigset_t *set);
int sigismember( const sigset_t *set, int signo);
int sigignore(int signo);
_sa_handler_t signal(int signo, _sa_handler_t func);
int sigorset( sigset_t *dest, const sigset_t *left,
              const sigset_t *right);
int sigpause(int signo);
int sigpending( sigset_t *set);
int sigprocmask(int how, const sigset_t *set, sigset_t *oset);
int sigqueue(int pid, int signo, union sigval value);
int sigrelse(int signo);
_sa_handler_t sigset(int signo, _sa_handler_t func);
int sigwait( const sigset_t *set, int *sig);
int sigtimedwait( const sigset_t *set, struct siginfo *value,
                  const struct timespec *timeout);
int sigsuspend( const sigset_t *sigmask);
int sigwaitinfo( const sigset_t *set, struct siginfo *value);
int sigaltstack( const stack_t *ss, stack_t *oss);
int siginterrupt(int signo, int flag);



int pthread_kill(pthread_t thread, int sig);
int pthread_sigmask(int how, const sigset_t *set, sigset_t *oset);
# 35 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/string.h" 1 3 4
# 33 "/tmp/tmpg1w5kvms/nuttx/include/string.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/stddef.h" 1 3 4
# 73 "/tmp/tmpg1w5kvms/nuttx/include/stddef.h" 3 4
typedef struct
{

  long long max_align_i;




  long double max_align_f;





} max_align_t;
# 34 "/tmp/tmpg1w5kvms/nuttx/include/string.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/alloca.h" 1 3 4
# 35 "/tmp/tmpg1w5kvms/nuttx/include/string.h" 2 3 4
# 66 "/tmp/tmpg1w5kvms/nuttx/include/string.h" 3 4
 char *strdup( const char *s) __attribute__((__malloc__(__builtin_free, 1)));
 char *strndup( const char *s, size_t size) __attribute__((__malloc__(__builtin_free, 1)));
 char *strerror(int);
int strerror_r(int, char *, size_t);
size_t strlen( const char *);
size_t strnlen( const char *, size_t);
 char *strcat( char *, const char *);
size_t strlcat( char *, const char *, size_t);
 char *strncat( char *, const char *, size_t);
int strcmp( const char *, const char *);
int strncmp( const char *, const char *, size_t);
int strcoll( const char *, const char *s2);
 char *strcpy( char *dest, const char *src);
 char *stpcpy( char *dest, const char *src);
size_t strlcpy( char *dst, const char *src, size_t size);
 char *strncpy( char *, const char *, size_t);
 char *stpncpy( char *, const char *, size_t);
 char *strpbrk( const char *, const char *);
 char *strchr( const char *s, int c);
 char *strchrnul( const char *s, int c);
 char *strrchr( const char *s, int c);
size_t strspn( const char *, const char *);
size_t strcspn( const char *, const char *);
 char *strstr( const char *, const char *);
 char *strcasestr( const char *, const char *);
 char *strsep( char **, const char *);
 char *strsignal(int signum);
 char *strtok( char *, const char *);
 char *strtok_r( char *, const char *, char **);
size_t strxfrm( char *, const char *, size_t n);
int strverscmp( const char *s1, const char *s2);

 void *memchr( const void *s, int c, size_t n);
 void *memrchr( const void *s, int c, size_t n);
 void *rawmemchr( const void *s, int c);
 void *memccpy( void *s1, const void *s2, int c, size_t n);
int memcmp( const void *s1, const void *s2, size_t n);
 void *memcpy( void *dest, const void *src, size_t n) __attribute__((used));
 void *mempcpy( void *dest, const void *src, size_t n);
 void *memmove( void *dest, const void *src, size_t count);
 void *memset( void *s, int c, size_t n) __attribute__((used));
 void *memmem( const void *haystack, size_t haystacklen,
                  const void *needle, size_t needlelen);

void explicit_bzero( void *s, size_t n);
int timingsafe_bcmp( const void *b1, const void *b2, size_t n);






 char *nx_strdup( const char *s) __attribute__((__malloc__(__builtin_free, 1)));
 char *nx_strndup( const char *s, size_t size) __attribute__((__malloc__(__builtin_free, 1)));
# 36 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 1 3 4
# 37 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 2 3 4
# 85 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 3 4
struct fd_set_s
{
  uint32_t arr[((256 + 31) / 32)];
};

typedef struct fd_set_s fd_set;
# 105 "/tmp/tmpg1w5kvms/nuttx/include/sys/select.h" 3 4
struct timeval;
int select(int nfds, fd_set *readfds, fd_set *writefds,
           fd_set *exceptfds, struct timeval *timeout);

int pselect(int nfds, fd_set *readfds, fd_set *writefds,
            fd_set *exceptfds, const struct timespec *timeout,
            const sigset_t *sigmask);
# 34 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 2 3 4
# 129 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
typedef clock_t hrtime_t;



struct timeval
{
  time_t tv_sec;
  long tv_usec;
};





struct itimerval
{
  struct timeval it_interval;
  struct timeval it_value;
};





struct timezone
{
  int tz_minuteswest;
  int tz_dsttime;
};
# 194 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
int gettimeofday( struct timeval *tv, struct timezone *tz);
# 217 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
int settimeofday( const struct timeval *tv,
                 const struct timezone *tz);
# 290 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
int getitimer(int which, struct itimerval *value);
# 340 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
int setitimer(int which, const struct itimerval *value,
              struct itimerval *ovalue);
# 377 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
int utimes( const char *path, const struct timeval times[2]);
int lutimes( const char *path, const struct timeval times[2]);
int futimesat(int dirfd, const char *path,
              const struct timeval times[2]);
# 400 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
int futimes(int fd, const struct timeval tv[2]);
# 413 "/tmp/tmpg1w5kvms/nuttx/include/sys/time.h" 3 4
hrtime_t gethrtime(void);
# 31 "/tmp/tmpg1w5kvms/nuttx/include/sys/timex.h" 2 3 4
# 56 "/tmp/tmpg1w5kvms/nuttx/include/sys/timex.h" 3 4
struct timex
{
  unsigned int modes;
  long offset;
  long freq;
  long maxerror;
  long esterror;
  int status;
  long constant;
  long precision;
  long tolerance;
  struct timeval time;
  long tick;
  long ppsfreq;
  long jitter;
  int shift;
  long stabil;
  long jitcnt;
  long calcnt;
  long errcnt;
  long stbcnt;
  int tai;
};
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 2 3 4






# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/inttypes.h" 1 3 4
# 383 "/tmp/tmpg1w5kvms/nuttx/include/inttypes.h" 3 4
struct imaxdiv_s
{
  intmax_t quot;
  intmax_t rem;
};

typedef struct imaxdiv_s imaxdiv_t;
# 407 "/tmp/tmpg1w5kvms/nuttx/include/inttypes.h" 3 4
intmax_t imaxabs(intmax_t j);
imaxdiv_t imaxdiv(intmax_t number, intmax_t denom);
intmax_t strtoimax( const char *nptr, char **endptr, int base);
uintmax_t strtoumax( const char *nptr, char **endptr, int base);

intmax_t wcstoimax( const wchar_t *nptr, wchar_t **endptr, int base);
uintmax_t wcstoumax( const wchar_t *nptr, wchar_t **endptr, int base);
# 35 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/strings.h" 1 3 4
# 79 "/tmp/tmpg1w5kvms/nuttx/include/strings.h" 3 4
int ffs(int j);







int ffsl(long j);
# 97 "/tmp/tmpg1w5kvms/nuttx/include/strings.h" 3 4
int ffsll(long long j);
# 107 "/tmp/tmpg1w5kvms/nuttx/include/strings.h" 3 4
int fls(int j);





int flsl(long j);





int flsll(long long j);







unsigned int popcount(unsigned int j);
unsigned int popcountl(unsigned long j);
unsigned int popcountll(unsigned long long j);

 char *index( const char *s, int c);
 char *rindex( const char *s, int c);

int strcasecmp( const char *, const char *);
int strncasecmp( const char *, const char *, size_t);
# 37 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 2 3 4
# 81 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
struct int64_s
{




  uint32_t ls;
  int32_t ms;

};

struct uint64_s
{




  uint32_t ls;
  uint32_t ms;

};

typedef struct invdiv_param32_s
{
  uint32_t mult;
  uint8_t shift;
} invdiv_param32_t;

typedef struct invdiv_param64_s
{
  uint64_t mult;
  uint8_t shift;
} invdiv_param64_t;
# 383 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
static __attribute__((always_inline)) inline
void invdiv_init_param32(uint32_t d, invdiv_param32_t *param)
{
  int l = (((d) > 0 && ((d) & (d - 1)) == 0) ? (((sizeof(d) <= sizeof(long)) ? ((8 * sizeof(long)) - __builtin_clzl(d)) : ((8 * sizeof(long long)) - __builtin_clzll(d))) - 1) : ((sizeof(d) <= sizeof(long)) ? ((8 * sizeof(long)) - __builtin_clzl(d)) : ((8 * sizeof(long long)) - __builtin_clzll(d))));
  uint64_t t1 = (uint64_t)1 << 32;
  uint64_t t2 = (uint64_t)1 << l;

  param->mult = (t1 * (t2 - d)) / d + 1;

  param->shift = l - 1;



}
# 415 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
static __attribute__((always_inline)) inline
uint64_t invdiv_u32(uint32_t n, const invdiv_param32_t *param)
{
  uint8_t sh = param->shift;

  uint32_t m = param->mult;
  uint32_t t1 = ((uint64_t)m * n) >> 32;
  uint32_t t2 = (n - t1) >> 1;
# 431 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
  return (t1 + t2) >> sh;
}
# 472 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
static __attribute__((always_inline)) inline uint64_t invdiv_umulh64(uint64_t a, uint64_t b)
{



  uint64_t al = a & 4294967295ul;
  uint64_t ah = a >> 32;
  uint64_t bl = b & 4294967295ul;
  uint64_t bh = b >> 32;

  uint64_t m1 = al * bl;
  uint64_t m2 = ah * bl;
  uint64_t m3 = al * bh;
  uint64_t m4 = ah * bh;

  uint64_t c = (m1 >> 32) + (m2 & 4294967295ul) + (m3 & 4294967295ul);

  return m4 + (m2 >> 32) + (m3 >> 32) + (c >> 32);
# 504 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
}
# 521 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
static __attribute__((always_inline)) inline
void invdiv_init_param64(uint64_t d, invdiv_param64_t *param)
{
  int l = (((d) > 0 && ((d) & (d - 1)) == 0) ? (((sizeof(d) <= sizeof(long)) ? ((8 * sizeof(long)) - __builtin_clzl(d)) : ((8 * sizeof(long long)) - __builtin_clzll(d))) - 1) : ((sizeof(d) <= sizeof(long)) ? ((8 * sizeof(long)) - __builtin_clzl(d)) : ((8 * sizeof(long long)) - __builtin_clzll(d))));
  uint64_t t = ((uint64_t)1 << l) - d;




  uint64_t q[2];
  uint64_t mres[2];





  mres[1] = t;
  mres[0] = 0;
  q[0] = 0;
  q[1] = 0;



  do { uint32_t idx; uint32_t bits_per_idx = sizeof(uint64_t) * 8; uint32_t bits_max = bits_per_idx * 2; uint64_t reminder = 0ull; uint64_t high_rem = 0ull; for (idx = 0; idx < bits_max; idx++) { uint32_t bits = bits_max - idx - 1; uint32_t bits_idx = bits / bits_per_idx; uint32_t bits_idx_off = bits % bits_per_idx; reminder <<= 1u; reminder |= ((mres)[bits_idx] >> bits_idx_off) & 1u; if (reminder >= (d)) { reminder -= (d); q[bits_idx] |= (1ull << bits_idx_off); } else if (high_rem != 0) { uint64_t c = 0ull - (d); high_rem -= 1; reminder += c; q[bits_idx] |= (1ull << bits_idx_off); } high_rem += (reminder >> (bits_per_idx - 1)) & 1u; } } while(0);

  param->mult = q[0] + 1;



  param->shift = l - 1;
}
# 570 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
static __attribute__((always_inline)) inline
uint64_t invdiv_u64(uint64_t n, const invdiv_param64_t *param)
{
  uint64_t t1;
  uint64_t t2;
  uint64_t m = param->mult;
  uint8_t sh1 = 1;
  uint8_t sh2 = param->shift;






  t1 = invdiv_umulh64(n, m);
  t2 = (n - t1) >> sh1;

  return (t1 + t2) >> sh2;
}
# 629 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void uadd32x64(uint32_t term1, const struct uint64_s *term2,
               struct uint64_s *sum);
# 645 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void uadd64( const struct uint64_s *term1,
            const struct uint64_s *term2,
            struct uint64_s *sum);
# 665 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void usub64x32( const struct uint64_s *minuend, uint32_t subtrahend,
               struct uint64_s *difference);
# 683 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void usub64( const struct uint64_s *minuend,
            const struct uint64_s *subtrahend,
            struct uint64_s *difference);
# 700 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void umul32(uint32_t factor1, uint32_t factor2,
            struct uint64_s *product);
# 716 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void umul32x64(uint32_t factor1, const struct uint64_s *factor2,
              struct uint64_s *product);
# 732 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/math32.h" 3 4
void umul64( const struct uint64_s *factor1,
            const struct uint64_s *factor2,
            struct uint64_s *product);
# 40 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 2 3 4
# 321 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
typedef int32_t sclock_t;
# 537 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
int clock_realtime2absticks( const struct timespec *reltime,
                            clock_t *absticks);
# 589 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
int clock_isleapyear(int year);
# 599 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
int clock_daysbeforemonth(int month, _Bool leap_year);
# 617 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
int clock_dayoftheweek(int mday, int month, int year);
# 630 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
time_t clock_calendar2utc(int year, int month, int day);
# 719 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
clock_t clock_systime_ticks(void);
# 738 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
void clock_systime_timespec( struct timespec *ts);
# 755 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
static __attribute__((always_inline)) inline uint64_t clock_systime_nsec(void)
{
  struct timespec ts;
  clock_systime_timespec(&ts);
  return ((uint64_t)(&ts)->tv_sec * 1000000000L + (uint64_t)(&ts)->tv_nsec);
}
# 833 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
clock_t perf_gettime(void);





void perf_convert(clock_t elapsed, struct timespec *ts);





unsigned long perf_getfreq(void);
# 855 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/clock.h" 3 4
int nxclock_gettime(clockid_t clock_id, struct timespec *tp);
# 36 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 2 3 4
# 150 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_init( sem_t *sem, int pshared, int32_t value);
# 176 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_destroy( sem_t *sem);
# 206 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_wait( sem_t *sem);
int nxsem_wait_slow( sem_t *sem);
# 233 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_trywait( sem_t *sem);
int nxsem_trywait_slow( sem_t *sem);
# 280 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_timedwait( sem_t *sem, const struct timespec *abstime);
# 327 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_clockwait( sem_t *sem, clockid_t clockid,
                    const struct timespec *abstime);
# 353 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_tickwait( sem_t *sem, uint32_t delay);
# 384 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_post( sem_t *sem);
int nxsem_post_slow( sem_t *sem);
# 413 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_get_value( sem_t *sem, int *sval);
# 476 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_open( sem_t **sem, const char *name, int oflags, ...);
# 504 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_close( sem_t *sem);
# 527 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_unlink( const char *name);
# 549 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_reset( sem_t *sem, int16_t count);
# 609 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_set_protocol( sem_t *sem, int protocol);
# 634 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_wait_uninterruptible( sem_t *sem);
# 665 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_timedwait_uninterruptible( sem_t *sem,
                                    const struct timespec *abstime);
# 698 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_clockwait_uninterruptible( sem_t *sem, clockid_t clockid,
                                    const struct timespec *abstime);
# 730 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_tickwait_uninterruptible( sem_t *sem, uint32_t delay);
# 750 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_getprioceiling( const sem_t *sem, int *prioceiling);
# 770 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/semaphore.h" 3 4
int nxsem_setprioceiling( sem_t *sem, int prioceiling,
                         int *old_ceiling);
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 2 3 4
# 48 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
struct mutex_s
{
  sem_t sem;



};

typedef struct mutex_s mutex_t;

struct rmutex_s
{
  mutex_t mutex;
  unsigned int count;
};

typedef struct rmutex_s rmutex_t;
# 118 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxmutex_init( mutex_t *mutex);
# 134 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
_Bool nxmutex_is_hold( mutex_t *mutex);
# 162 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxmutex_ticklock( mutex_t *mutex, uint32_t delay);
# 189 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxmutex_clocklock( mutex_t *mutex, clockid_t clockid,
                      const struct timespec *abstime);
# 216 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxmutex_timedlock( mutex_t *mutex, unsigned int timeout);
# 237 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_lock( rmutex_t *rmutex);
# 262 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_trylock( rmutex_t *rmutex);
# 290 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_ticklock( rmutex_t *rmutex, uint32_t delay);
# 317 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_clocklock( rmutex_t *rmutex, clockid_t clockid,
                       const struct timespec *abstime);
# 345 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_timedlock( rmutex_t *rmutex, unsigned int timeout);
# 368 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_unlock( rmutex_t *rmutex);
# 387 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_breaklock( rmutex_t *rmutex, unsigned int *count);
# 406 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
int nxrmutex_restorelock( rmutex_t *rmutex, unsigned int count);
# 434 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline pid_t nxmutex_get_holder( mutex_t *mutex)
{
  uint32_t mholder = mutex->sem.val.mholder & ~((uint32_t)0x80000000);
  return (((mholder) & ((uint32_t)0x7ffffffe)) != ((uint32_t)0x7ffffffe)) ? (pid_t)mholder : -1;
}
# 455 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline _Bool nxmutex_is_locked( mutex_t *mutex)
{
  return (((mutex->sem.val.mholder) & ((uint32_t)0x7ffffffe)) != ((uint32_t)0x7ffffffe));
}
# 479 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_destroy( mutex_t *mutex)
{
  return nxsem_destroy(&mutex->sem);
}
# 504 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_lock( mutex_t *mutex)
{
  int ret;

  ret = nxsem_wait(&mutex->sem);
  if (ret >= 0)
    {
      ;
    }

  return ret;
}
# 538 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_trylock( mutex_t *mutex)
{
  int ret;

  ret = nxsem_trywait(&mutex->sem);
  if (ret >= 0)
    {
      ;
    }

  return ret;
}
# 571 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_unlock( mutex_t *mutex)
{
  return nxsem_post(&mutex->sem);
}
# 587 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline void nxmutex_reset( mutex_t *mutex)
{
  nxsem_reset(&mutex->sem, 1);
}
# 610 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_breaklock( mutex_t *mutex,
                                             unsigned int *locked)
{
  int ret = OK;

  *locked = (_Bool)0;
  ret = nxmutex_unlock(mutex);
  if (ret >= 0)
    {
      *locked = (_Bool)1;
    }

  return ret;
}
# 642 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_restorelock( mutex_t *mutex,
                                               unsigned int locked)
{
  return locked ? nxmutex_lock(mutex) : OK;
}
# 665 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxmutex_set_protocol( mutex_t *mutex,
                                                int protocol)
{
  return nxsem_set_protocol(&mutex->sem, protocol);
}
# 743 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxrmutex_init( rmutex_t *rmutex)
{
  rmutex->count = 0;
  return nxmutex_init(&rmutex->mutex);
}
# 765 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxrmutex_destroy( rmutex_t *rmutex)
{
  int ret = nxmutex_destroy(&rmutex->mutex);

  if (ret >= 0)
    {
      rmutex->count = 0;
    }

  return ret;
}
# 791 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline _Bool nxrmutex_is_hold( rmutex_t *rmutex)
{
  return nxmutex_is_hold(&rmutex->mutex);
}
# 814 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline _Bool nxrmutex_is_recursive( rmutex_t *rmutex)
{
  return rmutex->count > 1;
}
# 834 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline int nxrmutex_get_holder( rmutex_t *rmutex)
{
  return nxmutex_get_holder(&rmutex->mutex);
}
# 855 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline _Bool nxrmutex_is_locked( rmutex_t *rmutex)
{
  return nxmutex_is_locked(&rmutex->mutex);
}
# 871 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mutex.h" 3 4
static __attribute__((always_inline)) inline void nxrmutex_reset( rmutex_t *rmutex)
{
  rmutex->count = 0;
  nxmutex_reset(&rmutex->mutex);
}
# 47 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 1 3 4
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/gran.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 2 3 4





struct task_group_s;







struct mm_map_entry_s
{
  struct mm_map_entry_s *flink;
  void *vaddr;
  size_t length;
  off_t offset;
  int prot;
  int flags;
  union
  {
    void *p;
    int i;
  } priv;

  int (*msync)( struct mm_map_entry_s *entry, void *start,
               size_t length, int flags);
# 71 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
  int (*munmap)( struct task_group_s *group,
                struct mm_map_entry_s *entry,
                void *start,
                size_t length);
};



struct mm_map_s
{
  sq_queue_t mm_map_sq;
  size_t map_count;





  rmutex_t mm_map_mutex;
};
# 110 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
int mm_map_lock(void);
# 126 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
void mm_map_unlock(void);
# 143 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
void mm_map_initialize( struct mm_map_s *mm, _Bool kernel);
# 159 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
void mm_map_destroy( struct mm_map_s *mm);
# 261 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
int mm_map_add( struct mm_map_s *mm, struct mm_map_entry_s *entry);
# 281 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
 struct mm_map_entry_s *mm_map_next( struct mm_map_s *mm,
                           const struct mm_map_entry_s *entry);
# 300 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
 struct mm_map_entry_s *mm_map_find( struct mm_map_s *mm,
                                       const void *vaddr,
                                       size_t length);
# 327 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/map.h" 3 4
int mm_map_remove( struct mm_map_s *mm,
                  struct mm_map_entry_s *entry);
# 49 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spawn.h" 1 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spawn.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/spawn.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/spawn.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/sched.h" 1 3 4
# 191 "/tmp/tmpg1w5kvms/nuttx/include/sched.h" 3 4
struct sched_param
{
  int sched_priority;
# 204 "/tmp/tmpg1w5kvms/nuttx/include/sched.h" 3 4
};
# 227 "/tmp/tmpg1w5kvms/nuttx/include/sched.h" 3 4
int task_create( const char *name, int priority, int stack_size,
                   main_t entry, char * const argv[]);
int task_create_with_stack( const char *name, int priority,
                              void *stack_addr, int stack_size,
                              main_t entry, char * const argv[]);

int task_delete(pid_t pid);
int task_restart(pid_t pid);

int task_setcancelstate(int state, int *oldstate);
int task_setcanceltype(int type, int *oldtype);
void task_testcancel(void);



int sched_getcpu(void);
int sched_setparam(pid_t pid, const struct sched_param *param);
int sched_getparam(pid_t pid, struct sched_param *param);
int sched_setscheduler(pid_t pid, int policy,
                          const struct sched_param *param);
int sched_getscheduler(pid_t pid);
int sched_yield(void);
int sched_get_priority_max(int policy);
int sched_get_priority_min(int policy);
int sched_rr_get_interval(pid_t pid, struct timespec *interval);
# 268 "/tmp/tmpg1w5kvms/nuttx/include/sched.h" 3 4
void sched_lock(void);
void sched_unlock(void);
int sched_lockcount(void);



_Bool sched_idletask(void);
# 35 "/tmp/tmpg1w5kvms/nuttx/include/spawn.h" 2 3 4
# 77 "/tmp/tmpg1w5kvms/nuttx/include/spawn.h" 3 4
struct timespec;
struct posix_spawnattr_s
{


  uint8_t flags;
  uint8_t priority;
  uint8_t policy;






  sigset_t sigmask;
  size_t stacksize;


  void *stackaddr;






};

typedef struct posix_spawnattr_s posix_spawnattr_t;
# 114 "/tmp/tmpg1w5kvms/nuttx/include/spawn.h" 3 4
typedef void *posix_spawn_file_actions_t;
# 135 "/tmp/tmpg1w5kvms/nuttx/include/spawn.h" 3 4
int posix_spawn( pid_t *pid, const char *path,
      const posix_spawn_file_actions_t *file_actions,
      const posix_spawnattr_t *attr,
      char * const argv[], char * const envp[]);







int task_spawn( const char *name, main_t entry,
      const posix_spawn_file_actions_t *file_actions,
      const posix_spawnattr_t *attr,
      char * const argv[], char * const envp[]);






int posix_spawn_file_actions_init(
      posix_spawn_file_actions_t *file_actions);
int posix_spawn_file_actions_destroy(
      posix_spawn_file_actions_t *file_actions);



int posix_spawn_file_actions_addclose(
      posix_spawn_file_actions_t *file_actions,
      int fd);
int posix_spawn_file_actions_adddup2(
      posix_spawn_file_actions_t *file_actions,
      int fd1, int fd2);
int posix_spawn_file_actions_addopen(
      posix_spawn_file_actions_t *file_actions,
      int fd, const char *path, int oflags, mode_t mode);





int posix_spawnattr_init( posix_spawnattr_t *attr);

int posix_spawnattr_destroy( posix_spawnattr_t *attr);



int posix_spawnattr_getflags( const posix_spawnattr_t *attr,
                             short *flags);

int posix_spawnattr_getschedparam( const posix_spawnattr_t *attr,
                                  struct sched_param *param);
int posix_spawnattr_getschedpolicy( const posix_spawnattr_t *attr,
                                   int *policy);

int posix_spawnattr_getsigmask( const posix_spawnattr_t *attr,
                               sigset_t *sigmask);



int posix_spawnattr_setflags( posix_spawnattr_t *attr, short flags);

int posix_spawnattr_setschedparam( posix_spawnattr_t *attr,
                                  const struct sched_param *param);
int posix_spawnattr_setschedpolicy( posix_spawnattr_t *attr, int policy);

int posix_spawnattr_setsigmask( posix_spawnattr_t *attr,
                               const sigset_t *sigmask);



int posix_spawnattr_getstacksize( const posix_spawnattr_t *attr,
                                 size_t *stacksize);
int posix_spawnattr_setstacksize( posix_spawnattr_t *attr,
                                 size_t stacksize);
int posix_spawnattr_setpriority( posix_spawnattr_t *attr,
                                uint8_t priority);
uint8_t posix_spawnattr_getpriority( posix_spawnattr_t *attr);

int posix_spawnattr_getstackaddr( const posix_spawnattr_t *attr,
                                 void **stackaddr);
int posix_spawnattr_setstackaddr( posix_spawnattr_t *attr,
                                 void *stackaddr);
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spawn.h" 2 3 4
# 44 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spawn.h" 3 4
enum spawn_file_actions_e
{
  SPAWN_FILE_ACTION_NONE = 0,
  SPAWN_FILE_ACTION_CLOSE,
  SPAWN_FILE_ACTION_DUP2,
  SPAWN_FILE_ACTION_OPEN
};







struct spawn_general_file_action_s
{
  struct spawn_general_file_action_s *flink;
  enum spawn_file_actions_e action;
};

struct spawn_close_file_action_s
{
  struct spawn_general_file_action_s *flink;
  enum spawn_file_actions_e action;
  int fd;
};

struct spawn_dup2_file_action_s
{
  struct spawn_general_file_action_s *flink;
  enum spawn_file_actions_e action;
  int fd1;
  int fd2;
};

struct spawn_open_file_action_s
{
  struct spawn_general_file_action_s *flink;
  enum spawn_file_actions_e action;
  int fd;
  int oflags;
  mode_t mode;
  char path[1];

};
# 102 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spawn.h" 3 4
void add_file_action( posix_spawn_file_actions_t *file_action,
                     struct spawn_general_file_action_s *entry);

struct tcb_s;
int spawn_file_actions( struct tcb_s *tcb,
                       const posix_spawn_file_actions_t *actions);

_Bool
spawn_file_is_duplicateable( const posix_spawn_file_actions_t *actions,
                            int fd, _Bool cloexec);
# 50 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 1 3 4
# 39 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 1 3 4
# 37 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/syscall.h" 1 3 4
# 38 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 2 3 4
# 50 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/irq.h" 1 3 4
# 35 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 1 3 4
# 36 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/irq.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/stm32/chip.h" 1 3 4
# 37 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/irq.h" 2 3 4
# 87 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/stm32/stm32f40xxx_irq.h" 1 3 4
# 88 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/irq.h" 2 3 4
# 51 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 2 3 4
# 67 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 1 3 4
# 39 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/nvicpri.h" 1 3 4
# 30 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/nvicpri.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/arch/chip/chip.h" 1 3 4
# 31 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/nvicpri.h" 2 3 4
# 40 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 2 3 4
# 215 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 3 4
struct xcptcontext
{





  uint32_t *saved_regs;
# 250 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 3 4
  uint32_t *regs;
};
# 272 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 3 4
static __attribute__((always_inline,no_instrument_function)) inline uint8_t getprimask(void)
{
  uint32_t primask;
  __asm__ __volatile__
    (
     "\tmrs  %0, primask\n"
     : "=r" (primask)
     :
     : "memory");

  return (uint8_t)primask;
}

static __attribute__((always_inline,no_instrument_function)) inline void setprimask(uint32_t primask)
{
  __asm__ __volatile__
    (
      "\tmsr primask, %0\n"
      :
      : "r" (primask)
      : "memory");
}

static __attribute__((always_inline,no_instrument_function)) inline void cpsie(void)
{
  __asm__ __volatile__ ("\tcpsie  i\n");
}

static __attribute__((always_inline,no_instrument_function)) inline void cpsid(void)
{
  __asm__ __volatile__ ("\tcpsid  i\n");
}







static __attribute__((always_inline,no_instrument_function)) inline uint8_t getbasepri(void)
{
  uint32_t basepri;

  __asm__ __volatile__
    (
     "\tmrs  %0, basepri\n"
     : "=r" (basepri)
     :
     : "memory");

  return (uint8_t)basepri;
}

static __attribute__((always_inline,no_instrument_function)) inline void setbasepri(uint32_t basepri)
{
  __asm__ __volatile__
    (
      "\tmsr basepri, %0\n"
      :
      : "r" (basepri)
      : "memory");
}
# 376 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 3 4
static __attribute__((always_inline,no_instrument_function)) inline void up_irq_disable(void)
{


  setbasepri(0x80);;
}



static __attribute__((always_inline,no_instrument_function)) inline irqstate_t up_irq_save(void)
{


  uint8_t basepri = getbasepri();
  setbasepri(0x80);;
  return (irqstate_t)basepri;
}



static __attribute__((always_inline,no_instrument_function)) inline void up_irq_enable(void)
{


  setbasepri(0);
  __asm__ __volatile__ ("\tcpsie  i\n");
}



static __attribute__((always_inline,no_instrument_function)) inline void up_irq_restore(irqstate_t flags)
{


  setbasepri((uint32_t)flags);
}



static __attribute__((always_inline,no_instrument_function)) inline uint32_t getipsr(void)
{
  uint32_t ipsr;
  __asm__ __volatile__
    (
     "\tmrs  %0, ipsr\n"
     : "=r" (ipsr)
     :
     : "memory");

  return ipsr;
}



static __attribute__((always_inline,no_instrument_function)) inline uint32_t getfaultmask(void)
{
  uint32_t faultmask;
  __asm__ __volatile__
    (
     "\tmrs  %0, faultmask\n"
     : "=r" (faultmask)
     :
     : "memory");

  return faultmask;
}

static __attribute__((always_inline,no_instrument_function)) inline void setfaultmask(uint32_t faultmask)
{
  __asm__ __volatile__
    (
      "\tmsr faultmask, %0\n"
      :
      : "r" (faultmask)
      : "memory");
}



static __attribute__((always_inline,no_instrument_function)) inline uint32_t getcontrol(void)
{
  uint32_t control;
  __asm__ __volatile__
    (
     "\tmrs  %0, control\n"
     : "=r" (control)
     :
     : "memory");

  return control;
}

static __attribute__((always_inline,no_instrument_function)) inline void setcontrol(uint32_t control)
{
  __asm__ __volatile__
    (
      "\tmsr control, %0\n"
      :
      : "r" (control)
      : "memory");
}

static __attribute__((always_inline,no_instrument_function)) inline uint32_t getpsp(void)
{
  uint32_t psp;

  __asm__ __volatile__
    (
     "\tmrs  %0, psp\n"
     : "=r" (psp)
     :
     : "memory");

  return psp;
}
# 504 "/tmp/tmpg1w5kvms/nuttx/include/arch/armv7-m/irq.h" 3 4
static __attribute__((always_inline,no_instrument_function)) inline uint32_t up_getsp(void)
{
  register uint32_t sp;

  __asm__ __volatile__
  (
    "mov %0, sp\n"
    : "=r" (sp)
  );

  return sp;
}

static __attribute__((always_inline,no_instrument_function)) inline uintptr_t up_getusrsp(void *regs)
{
  uint32_t *ptr = (uint32_t *)regs;
  return ptr[(0)];
}

static __attribute__((always_inline,no_instrument_function)) inline _Bool up_interrupt_context(void)
{
  return getipsr() != 0;
}
# 68 "/tmp/tmpg1w5kvms/nuttx/include/arch/irq.h" 2 3 4
# 40 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 2 3 4
# 179 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 3 4
typedef uint8_t irq_t;
# 202 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 3 4
typedef int (*xcpt_t)(int irq, void *context, void *arg);
# 252 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 3 4
int irq_attach(int irq, xcpt_t isr, void *arg);
# 277 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 3 4
int irq_attach_thread(int irq, xcpt_t isr, xcpt_t isrthread, void *arg,
                      int priority, int stack_size);
# 302 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/irq.h" 3 4
int irq_attach_wqueue(int irq, xcpt_t isr, xcpt_t isrwork,
                      void *arg, int priority);
# 52 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spinlock_type.h" 1 3 4
# 56 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spinlock_type.h" 3 4
typedef uint8_t spinlock_t;
# 87 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/spinlock_type.h" 3 4
typedef union rspinlock_u
{


  uint32_t val;
  struct
    {
      uint16_t owner;
      uint16_t count;
    };
} rspinlock_t;



typedef struct seqcount_s
{
  uint32_t sequence;
} seqcount_t;
# 53 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 2 3 4
# 185 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
struct file;
struct inode;
struct stat;
struct statfs;
struct pollfd;
struct mtd_dev_s;
struct uio;





struct fs_dirent_s
{
# 207 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
  struct inode *fd_root;



  char *fd_path;
};





struct file_operations
{


  int (*open)( struct file *filep);






  int (*close)( struct file *filep);
  ssize_t (*read)( struct file *filep, char *buffer,
                       size_t buflen);
  ssize_t (*write)( struct file *filep, const char *buffer,
                        size_t buflen);
  off_t (*seek)( struct file *filep, off_t offset, int whence);
  int (*ioctl)( struct file *filep, int cmd, unsigned long arg);
  int (*mmap)( struct file *filep,
                       struct mm_map_entry_s *map);
  int (*truncate)( struct file *filep, off_t length);

  int (*poll)( struct file *filep, struct pollfd *fds,
                       _Bool setup);
  ssize_t (*readv)( struct file *filep, struct uio *uio);
  ssize_t (*writev)( struct file *filep, struct uio *uio);




  int (*unlink)( struct inode *inode);

};
# 261 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
struct inode;
struct block_operations
{
  int (*open)( struct inode *inode);
  int (*close)( struct inode *inode);
  ssize_t (*read)( struct inode *inode, unsigned char *buffer,
                       blkcnt_t start_sector, unsigned int nsectors);
  ssize_t (*write)( struct inode *inode,
                        const unsigned char *buffer,
                        blkcnt_t start_sector, unsigned int nsectors);
  int (*geometry)( struct inode *inode,
                           struct geometry *geometry);
  int (*ioctl)( struct inode *inode, int cmd, unsigned long arg);

  int (*unlink)( struct inode *inode);

};







struct mountpt_operations
{






  int (*open)( struct file *filep, const char *relpath,
                       int oflags, mode_t mode);






  int (*close)( struct file *filep);
  ssize_t (*read)( struct file *filep, char *buffer,
                       size_t buflen);
  ssize_t (*write)( struct file *filep, const char *buffer,
                        size_t buflen);
  off_t (*seek)( struct file *filep, off_t offset, int whence);
  int (*ioctl)( struct file *filep, int cmd, unsigned long arg);
  int (*mmap)( struct file *filep,
                       struct mm_map_entry_s *map);
  int (*truncate)( struct file *filep, off_t length);
  int (*poll)( struct file *filep, struct pollfd *fds,
                       _Bool setup);
  ssize_t (*readv)( struct file *filep, struct uio *uio);
  ssize_t (*writev)( struct file *filep, struct uio *uio);
# 323 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
  int (*sync)( struct file *filep);
  int (*dup)( const struct file *oldp, struct file *newp);
  int (*fstat)( const struct file *filep, struct stat *buf);
  int (*fchstat)( const struct file *filep,
                          const struct stat *buf, int flags);



  int (*opendir)( struct inode *mountpt, const char *relpath,
                          struct fs_dirent_s **dir);
  int (*closedir)( struct inode *mountpt,
                           struct fs_dirent_s *dir);
  int (*readdir)( struct inode *mountpt,
                          struct fs_dirent_s *dir,
                          struct dirent *entry);
  int (*rewinddir)( struct inode *mountpt,
                            struct fs_dirent_s *dir);



  int (*bind)( struct inode *blkdriver, const void *data,
                       void **handle);
  int (*unbind)( void *handle, struct inode **blkdriver,
                         unsigned int flags);
  int (*statfs)( struct inode *mountpt, struct statfs *buf);



  int (*unlink)( struct inode *mountpt, const char *relpath);
  int (*mkdir)( struct inode *mountpt, const char *relpath,
                        mode_t mode);
  int (*rmdir)( struct inode *mountpt, const char *relpath);
  int (*rename)( struct inode *mountpt,
                         const char *oldrelpath,
                         const char *newrelpath);
  int (*stat)( struct inode *mountpt, const char *relpath,
                       struct stat *buf);
  int (*chstat)( struct inode *mountpt, const char *relpath,
                         const struct stat *buf, int flags);
  int (*syncfs)( struct inode *mountpt);
};
# 380 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
union inode_ops_u
{
  const struct file_operations *i_ops;

  const struct block_operations *i_bops;
  struct mtd_dev_s *i_mtd;
  const struct mountpt_operations *i_mops;
# 397 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
};



struct inode
{
  struct inode *i_parent;
  struct inode *i_peer;
  struct inode *i_child;
  atomic_t i_crefs;
  uint16_t i_flags;
  union inode_ops_u u;
  ino_t i_ino;
  size_t i_size;
# 419 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
  void *i_private;
  char i_name[1];
};
# 434 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
typedef ssize_t cookie_read_function_t( void *cookie, char *buf,
                                            size_t size);
typedef ssize_t cookie_write_function_t( void *cookie,
                                             const char *buf,
                                             size_t size);
typedef off_t cookie_seek_function_t( void *cookie,
                                          off_t *offset,
                                          int whence);
typedef int cookie_close_function_t( void *cookie);

typedef struct cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;






struct file
{
  int f_oflags;
  atomic_t f_refs;
  off_t f_pos;
  struct inode *f_inode;
  void *f_priv;



};

struct fd
{
  struct file *f_file;
  _Bool f_cloexec;
# 482 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
};
# 491 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
struct fdlist
{
  spinlock_t fl_lock;
  uint8_t fl_rows;
  struct fd **fl_fds;







  struct fd *fl_prefd;
  struct fd fl_prefds[8];
};
# 544 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
struct file_struct
{
  sq_entry_t fs_entry;
  rmutex_t fs_lock;
  cookie_io_functions_t fs_iofunc;
  void *fs_cookie;

  char *fs_bufstart;
  char *fs_bufend;
  char *fs_bufpos;
  char *fs_bufread;

  char fs_buffer[64];


  uint16_t fs_oflags;
  uint8_t fs_flags;

  uint8_t fs_nungotten;
  char fs_ungotten[2];

};

struct streamlist
{
  mutex_t sl_lock;
  struct file_struct sl_std[3];
  sq_queue_t sl_queue;
};
# 597 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
void fs_initialize(void);
# 622 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int register_driver( const char *path,
                    const struct file_operations *fops, mode_t mode,
                    void *priv);
# 651 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int register_driver_with_size( const char *path,
                              const struct file_operations *fops,
                              mode_t mode, void *priv, size_t size);
# 679 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int register_blockdriver( const char *path,
                         const struct block_operations *bops,
                         mode_t mode, void *priv);
# 709 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int register_merge_blockdriver( const char *merge, ...);
# 736 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int register_blockpartition( const char *partition,
                            mode_t mode, const char *parent,
                            off_t firstsector, off_t nsectors);
# 749 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int unregister_driver( const char *path);
# 759 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int unregister_blockdriver( const char *path);
# 887 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_mount( const char *source, const char *target,
             const char *filesystemtype, unsigned long mountflags,
             const void *data);
# 908 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_umount2( const char *target, unsigned int flags);
# 919 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
void fdlist_init( struct fdlist *list);
# 946 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
void fdlist_free( struct fdlist *list);
# 962 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_count( struct fdlist *list);
# 976 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_copy( struct fdlist *plist, struct fdlist *clist,
                const posix_spawn_file_actions_t *actions,
                _Bool cloexec);
# 999 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_get2( struct fdlist *list, int fd,
                struct file **filep, struct fd **fdp);
# 1035 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_dupfile( struct fdlist *list, int oflags, int minfd,
                   struct file *filep);
# 1051 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_allocate_from_inode( struct inode *inode, int oflags, off_t pos,
                             void *priv, int minfd);
# 1067 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_dup( struct file *filep, int minfd, int flags);
# 1085 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_dup2( struct file *filep1, struct file *filep2);
# 1106 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_dup3( struct fdlist *list, int fd1, int fd2, int flags);
# 1127 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_dup2( struct fdlist *list, int fd1, int fd2);
# 1145 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_dup2(int fd1, int fd2);
# 1168 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_open( struct file *filep, const char *path, int oflags, ...);
# 1193 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_open( struct fdlist *list,
                const char *path, int oflags, ...);
# 1212 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_open( const char *path, int oflags, ...);
# 1222 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
 struct file *file_allocate(void);
# 1232 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
void file_deallocate( struct file *filep);
# 1252 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_get2(int fd, struct file **filep, struct fd **fdp);
# 1288 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
void file_ref( struct file *filep);
# 1303 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_put( struct file *filep);
# 1321 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_close( struct file *filep);
# 1346 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int fdlist_close( struct fdlist *list, int fd);
# 1364 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_close(int fd);
# 1380 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
 void *find_driver( const char *pathname);
# 1405 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int open_blockdriver( const char *pathname, int mountflags,
                     struct inode **ppinode);
# 1426 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int close_blockdriver( struct inode *inode);
# 1450 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int find_blockdriver( const char *pathname, int mountflags,
                     struct inode **ppinode);
# 1471 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int find_mtddriver( const char *pathname, struct inode **ppinode);
# 1489 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int close_mtddriver( struct inode *pinode);
# 1514 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t file_read( struct file *filep, void *buf, size_t nbytes);
ssize_t file_readv( struct file *filep,
                   const struct iovec *iov, int iovcnt);
# 1539 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t nx_read(int fd, void *buf, size_t nbytes);
ssize_t nx_readv(int fd, const struct iovec *iov, int iovcnt);
# 1568 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t file_write( struct file *filep, const void *buf,
                   size_t nbytes);
ssize_t file_writev( struct file *filep,
                    const struct iovec *iov, int iovcnt);
# 1598 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t nx_write(int fd, const void *buf, size_t nbytes);
ssize_t nx_writev(int fd, const struct iovec *iov, int iovcnt);
# 1611 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t file_pread( struct file *filep, void *buf, size_t nbytes,
                   off_t offset);
# 1624 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t file_pwrite( struct file *filep, const void *buf,
                    size_t nbytes, off_t offset);
# 1636 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
ssize_t file_sendfile( struct file *outfile, struct file *infile,
                      off_t *offset, size_t count);
# 1649 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
off_t file_seek( struct file *filep, off_t offset, int whence);
# 1665 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
off_t nx_seek(int fd, off_t offset, int whence);
# 1677 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_fsync( struct file *filep);
# 1689 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_syncfs( struct file *filep);
# 1701 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_truncate( struct file *filep, off_t length);
# 1713 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_mmap( struct file *filep, void *start, size_t length,
              int prot, int flags, off_t offset, void **mapped);
# 1725 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_munmap( void *start, size_t length);
# 1745 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_ioctl( struct file *filep, int req, ...);
# 1766 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_fcntl( struct file *filep, int cmd, ...);
# 1786 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_poll( struct file *filep, struct pollfd *fds, _Bool setup);
# 1811 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_fstat( struct file *filep, struct stat *buf);
# 1828 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_fstat(int fd, struct stat *buf);
# 1845 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_stat( const char *path, struct stat *buf, int resolve);
# 1870 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int file_fchstat( struct file *filep, struct stat *buf, int flags);
# 1887 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int nx_unlink( const char *pathname);
# 1971 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/fs/fs.h" 3 4
int map_anonymous( struct mm_map_entry_s *entry, _Bool kernel);
# 37 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 2 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/lib.h" 1 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/lib.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/kmalloc.h" 1 3 4
# 34 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/kmalloc.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/stdlib.h" 1 3 4
# 92 "/tmp/tmpg1w5kvms/nuttx/include/stdlib.h" 3 4
struct div_s
{
  int quot;
  int rem;
};

typedef struct div_s div_t;



struct ldiv_s
{
  long quot;
  long rem;
};

typedef struct ldiv_s ldiv_t;



struct lldiv_s
{
  long quot;
  long rem;
};

typedef struct lldiv_s lldiv_t;
# 135 "/tmp/tmpg1w5kvms/nuttx/include/stdlib.h" 3 4
void srand(unsigned int seed);
int rand(void);
int rand_r( unsigned int *seedp);
void lcong48( unsigned short int param[7]);
 unsigned short int *seed48( unsigned short int seed16v[3]);
void srand48(long int seedval);

long int jrand48( unsigned short int xsubi[3]);
long int lrand48(void);
long int mrand48(void);
long int nrand48( unsigned short int xsubi[3]);

double drand48(void);
double erand48( unsigned short int xsubi[3]);




long random(void);

void arc4random_buf( void *bytes, size_t nbytes);
uint32_t arc4random(void);



 char **get_environ_ptr(void);
 char *getenv( const char *name);
int putenv( const char *string);
int clearenv(void);
int setenv( const char *name, const char *value, int overwrite);
int unsetenv( const char *name);



void exit(int status) __attribute__((noreturn));
void quick_exit(int status) __attribute__((noreturn));
void abort(void) __attribute__((noreturn));
int atexit( void (*func)(void));
int at_quick_exit( void (*func)(void));
int on_exit( void (*func)(int, void *), void *arg);



void _Exit(int status) __attribute__((noreturn));
# 187 "/tmp/tmpg1w5kvms/nuttx/include/stdlib.h" 3 4
int system( const char *cmd);


 char *realpath( const char *path, char *resolved);



long strtol( const char *nptr, char **endptr, int base);
unsigned long strtoul( const char *nptr, char **endptr, int base);

long long strtoll( const char *nptr, char **endptr, int base);
unsigned long long strtoull( const char *nptr, char **endptr,
                            int base);

float strtof( const char *str, char **endptr);

double strtod( const char *str, char **endptr);


long double strtold( const char *str, char **endptr);


int atoi( const char *nptr);
long atol( const char *nptr);

long long atoll( const char *nptr);


double atof( const char *nptr);




 char *itoa(int val, char *str, int base);



int mblen( const char *s, size_t n);
int mbtowc( wchar_t *pwc, const char *s, size_t n);
size_t mbstowcs( wchar_t *dst, const char *src, size_t len);
int wctomb( char *s, wchar_t wchar);
size_t wcstombs( char *dst, const wchar_t *src, size_t len);



 void *malloc(size_t) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(1)));
 void *valloc(size_t) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(1)));
void free( void *);
 void *realloc( void *, size_t) __attribute__((__alloc_size__(2)));
 void *reallocarray( void *, size_t, size_t) __attribute__((__alloc_size__(2, 3)));
 void *memalign(size_t, size_t) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(2)));
 void *zalloc(size_t) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(1)));
 void *calloc(size_t, size_t) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(1, 2)));
 void *aligned_alloc(size_t, size_t) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(2)));
int posix_memalign( void **, size_t, size_t);
# 258 "/tmp/tmpg1w5kvms/nuttx/include/stdlib.h" 3 4
int abs(int j);
long int labs(long int j);

long long int llabs(long long int j);


div_t div(int number, int denom);
ldiv_t ldiv(long number, long denom);

lldiv_t lldiv(long long number, long long denom);




 char *mktemp( char *path_template);
int mkstemp( char *path_template);
 char *mkdtemp( char *path_template);



void qsort( void *base, size_t nel, size_t width,
                int (*compar)( const void *, const void *));



 void *bsearch( const void *key, const void *base, size_t nel,
                   size_t width, int (*compar)( const void *,
                   const void *));



 const char *getprogname(void);



int __cxa_atexit( void (*func)( void *), void *arg,
                 void *dso_handle);
# 35 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/kmalloc.h" 2 3 4

# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 1 3 4
# 31 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/userspace.h" 1 3 4
# 35 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/userspace.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 1 3 4
# 37 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
# 1 "/tmp/tmpg1w5kvms/nuttx/include/unistd.h" 1 3 4
# 350 "/tmp/tmpg1w5kvms/nuttx/include/unistd.h" 3 4
pid_t fork(void);
pid_t vfork(void);
pid_t getpid(void);
pid_t getpgid(pid_t pid);
pid_t getpgrp(void);
pid_t gettid(void);
pid_t getppid(void);
void _exit(int status) __attribute__((noreturn));
unsigned int sleep(unsigned int seconds);
int usleep(useconds_t usec);
int pause(void);
int nice(int inc);

int daemon(int nochdir, int noclose);



int close(int fd);
int dup(int fd);
int dup2(int fd1, int fd2);
int dup3(int fd1, int fd2, int flags);
int fsync(int fd);
off_t lseek(int fd, off_t offset, int whence);
ssize_t read(int fd, void *buf, size_t nbytes);
ssize_t write(int fd, const void *buf, size_t nbytes);
ssize_t pread(int fd, void *buf, size_t nbytes, off_t offset);
ssize_t pwrite(int fd, const void *buf, size_t nbytes, off_t offset);
int ftruncate(int fd, off_t length);
int fchown(int fd, uid_t owner, gid_t group);
int lockf(int fd, int cmd, off_t len);



int isatty(int fd);

 char *ttyname(int fd);
int ttyname_r(int fd, char *buf, size_t buflen);
# 397 "/tmp/tmpg1w5kvms/nuttx/include/unistd.h" 3 4
int pipe(int pipefd[2]);
int pipe2(int pipefd[2], int flags);



unsigned int alarm(unsigned int seconds);



int chdir( const char *path);
int fchdir(int fd);
 char *getcwd( char *buf, size_t size);
 char *get_current_dir_name(void);



int access( const char *path, int amode);
int faccessat(int dirfd, const char *path, int mode, int flags);
int rmdir( const char *pathname);
int unlink( const char *pathname);
int unlinkat(int dirfd, const char *pathname, int flags);
int truncate( const char *path, off_t length);
int link( const char *path1, const char *path2);
int linkat(int olddirfd, const char *path1,
               int newdirfd, const char *path2, int flags);
int symlink( const char *path1, const char *path2);
int symlinkat( const char *path1, int dirfd,
                  const char *path2);
ssize_t readlink( const char *path, char *buf, size_t bufsize);
ssize_t readlinkat(int dirfd, const char *path, char *buf,
                   size_t bufsize);
int chown( const char *path, uid_t owner, gid_t group);
int lchown( const char *path, uid_t owner, gid_t group);
int fchownat(int dirfd, const char *path, uid_t owner,
                 gid_t group, int flags);
# 445 "/tmp/tmpg1w5kvms/nuttx/include/unistd.h" 3 4
void swab( const void *src, void *dest, ssize_t nbytes);



int getopt(int argc, char * const argv[], const char *optstring);



 char **getoptargp(void);
 int *getopterrp(void);
 int *getoptindp(void);
 int *getoptoptp(void);

int gethostname( char *name, size_t namelen);
int sethostname( const char *name, size_t namelen);



long sysconf(int name);
long fpathconf(int fildes, int name);
long pathconf( const char *path, int name);
size_t confstr(int name, char *buf, size_t len);



int setuid(uid_t uid);
uid_t getuid(void);
int setgid(gid_t gid);
gid_t getgid(void);

int seteuid(uid_t uid);
uid_t geteuid(void);
int setegid(gid_t gid);
gid_t getegid(void);

int setreuid(uid_t ruid, uid_t euid);
int setregid(gid_t rgid, gid_t egid);

int getentropy( void *buffer, size_t length);

void sync(void);
int syncfs(int fd);

int profil( unsigned short *buf, size_t bufsiz,
               size_t offset, unsigned int scale);

 char *getpass( const char *prompt);
# 38 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 2 3 4
# 215 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
typedef void *pthread_addr_t;



typedef pthread_addr_t (*pthread_startroutine_t)(pthread_addr_t);
typedef pthread_startroutine_t pthread_func_t;

typedef void (*pthread_trampoline_t)(pthread_startroutine_t, pthread_addr_t);

struct pthread_attr_s
{
  uint8_t priority;
  uint8_t policy;
  uint8_t inheritsched;
  uint8_t detachstate;
# 239 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
  void *stackaddr;
  size_t stacksize;
  size_t guardsize;





};
# 259 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
struct pthread_condattr_s
{
  int pshared;
  clockid_t clockid;
};






struct pthread_cond_s
{
  sem_t sem;
  clockid_t clockid;
  int wait_count;
};
# 284 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
struct pthread_mutexattr_s
{
  uint8_t pshared : 1;
# 297 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
  uint8_t robust : 1;

};






struct pthread_mutex_s
{



  struct pthread_mutex_s *flink;
  uint8_t flags;
# 321 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
  mutex_t mutex;

};
# 380 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
struct pthread_barrierattr_s
{
  int pshared;
};


typedef struct pthread_barrierattr_s pthread_barrierattr_t;



struct pthread_barrier_s
{
  sem_t sem;
  unsigned int count;
  unsigned int wait_count;
  mutex_t mutex;
};


typedef struct pthread_barrier_s pthread_barrier_t;



struct pthread_once_s
{
  volatile _Bool done;
  pthread_mutex_t mutex;
};






struct pthread_rwlockattr_s
{
  int pshared;
};


typedef struct pthread_rwlockattr_s pthread_rwlockattr_t;



struct pthread_rwlock_s
{
  pthread_mutex_t lock;
  pthread_cond_t cv;
  unsigned int num_readers;
  unsigned int num_writers;
  _Bool write_in_progress;
};


typedef struct pthread_rwlock_s pthread_rwlock_t;
# 462 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
typedef void (*pthread_cleanup_t)( void *arg);



struct sched_param;
# 476 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
int pthread_attr_init( pthread_attr_t *attr);



int pthread_attr_destroy( pthread_attr_t *attr);



int pthread_attr_setschedpolicy( pthread_attr_t *attr, int policy);
int pthread_attr_getschedpolicy( const pthread_attr_t *attr,
                                int *policy);
int pthread_attr_setschedparam( pthread_attr_t *attr,
                               const struct sched_param *param);
int pthread_attr_getschedparam( const pthread_attr_t *attr,
                               struct sched_param *param);
int pthread_attr_setinheritsched( pthread_attr_t *attr,
                                 int inheritsched);
int pthread_attr_getinheritsched( const pthread_attr_t *attr,
                                 int *inheritsched);
int pthread_attr_getdetachstate( const pthread_attr_t *attr,
                                int *detachstate);
int pthread_attr_setdetachstate( pthread_attr_t *attr,
                                int detachstate);
# 512 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
int pthread_attr_setstackaddr( pthread_attr_t *attr, void *stackaddr);
int pthread_attr_getstackaddr( const pthread_attr_t *attr,
                              void **stackaddr);



int pthread_attr_setstacksize( pthread_attr_t *attr, size_t stacksize);
int pthread_attr_getstacksize( const pthread_attr_t *attr,
                              size_t *stacksize);



int pthread_attr_setstack( pthread_attr_t *attr,
                          void *stackaddr, size_t stacksize);
int pthread_attr_getstack( const pthread_attr_t *attr,
                          void **stackaddr, size_t *stacksize);



int pthread_attr_setscope( pthread_attr_t *attr, int scope);
int pthread_attr_getscope( const pthread_attr_t *attr, int *scope);



int pthread_attr_setguardsize( pthread_attr_t *attr, size_t guardsize);
int pthread_attr_getguardsize( const pthread_attr_t *attr,
                              size_t *guardsize);



int pthread_setname_np(pthread_t thread, const char *name);
int pthread_getname_np(pthread_t thread, char *name, size_t len);



 void *pthread_get_stackaddr_np(pthread_t thread);
ssize_t pthread_get_stacksize_np(pthread_t thread);
# 557 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
int pthread_create( pthread_t *thread, const pthread_attr_t *attr,
                   pthread_startroutine_t startroutine, pthread_addr_t arg);





int pthread_detach(pthread_t thread);





void pthread_exit(pthread_addr_t value) __attribute__((noreturn));
int pthread_cancel(pthread_t thread);
int pthread_setcancelstate(int state, int *oldstate);
int pthread_setcanceltype(int type, int *oldtype);
void pthread_testcancel(void);
# 592 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
int pthread_join(pthread_t thread, pthread_addr_t *value);





void pthread_yield(void);



pthread_t pthread_self(void);
pid_t pthread_gettid_np(pthread_t thread);



int pthread_equal(pthread_t t1, pthread_t t2);



int pthread_getschedparam(pthread_t thread, int *policy,
                          struct sched_param *param);
int pthread_setschedparam(pthread_t thread, int policy,
                          const struct sched_param *param);
int pthread_setschedprio(pthread_t thread, int prio);
# 631 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
int pthread_setconcurrency(int new_level);
int pthread_getconcurrency(void);



int pthread_key_create( pthread_key_t *key,
                       void (*destructor)( void *));
int pthread_setspecific(pthread_key_t key, const void *value);
 void *pthread_getspecific(pthread_key_t key);
int pthread_key_delete(pthread_key_t key);



int pthread_mutexattr_init( pthread_mutexattr_t *attr);
int pthread_mutexattr_destroy( pthread_mutexattr_t *attr);
int pthread_mutexattr_getpshared( const pthread_mutexattr_t *attr,
                                 int *pshared);
int pthread_mutexattr_setpshared( pthread_mutexattr_t *attr,
                                 int pshared);
int pthread_mutexattr_gettype( const pthread_mutexattr_t *attr,
                              int *type);
int pthread_mutexattr_settype( pthread_mutexattr_t *attr, int type);
int pthread_mutexattr_getprotocol( const pthread_mutexattr_t *attr,
                                  int *protocol);
int pthread_mutexattr_setprotocol( pthread_mutexattr_t *attr,
                                  int protocol);
int pthread_mutexattr_getrobust( const pthread_mutexattr_t *attr,
                                int *robust);
int pthread_mutexattr_setrobust( pthread_mutexattr_t *attr,
                                int robust);
int pthread_mutexattr_getprioceiling( const pthread_mutexattr_t *attr,
                                     int *prioceiling);
int pthread_mutexattr_setprioceiling( pthread_mutexattr_t *attr,
                                     int prioceiling);
int pthread_mutex_getprioceiling( const pthread_mutex_t *mutex,
                                 int *prioceiling);
int pthread_mutex_setprioceiling( pthread_mutex_t *mutex,
                                 int prioceiling, int *old_ceiling);



int pthread_mutex_init( pthread_mutex_t *mutex,
                       const pthread_mutexattr_t *attr);
int pthread_mutex_destroy( pthread_mutex_t *mutex);
int pthread_mutex_lock( pthread_mutex_t *mutex);
int pthread_mutex_timedlock( pthread_mutex_t *mutex,
                            const struct timespec *abs_timeout);
int pthread_mutex_trylock( pthread_mutex_t *mutex);
int pthread_mutex_unlock( pthread_mutex_t *mutex);




int pthread_mutex_consistent( pthread_mutex_t *mutex);




int pthread_condattr_init( pthread_condattr_t *attr);
int pthread_condattr_destroy( pthread_condattr_t *attr);
int pthread_condattr_getpshared( const pthread_condattr_t *attr,
                                int *pshared);
int pthread_condattr_setpshared( pthread_condattr_t *attr, int pshared);
int pthread_condattr_getclock( const pthread_condattr_t *attr,
                              clockid_t *clock_id);
int pthread_condattr_setclock( pthread_condattr_t *attr,
                              clockid_t clock_id);



int pthread_cond_init( pthread_cond_t *cond,
                      const pthread_condattr_t *attr);
int pthread_cond_destroy( pthread_cond_t *cond);



int pthread_cond_broadcast( pthread_cond_t *cond);
int pthread_cond_signal( pthread_cond_t *cond);



int pthread_cond_wait( pthread_cond_t *cond, pthread_mutex_t *mutex);



int pthread_cond_timedwait( pthread_cond_t *cond,
                           pthread_mutex_t *mutex,
                           const struct timespec *abstime);

int pthread_cond_clockwait( pthread_cond_t *cond,
                           pthread_mutex_t *mutex,
                           clockid_t clockid,
                           const struct timespec *abstime);



int pthread_barrierattr_destroy( pthread_barrierattr_t *attr);
int pthread_barrierattr_init( pthread_barrierattr_t *attr);
int pthread_barrierattr_getpshared( const pthread_barrierattr_t *attr,
                                   int *pshared);
int pthread_barrierattr_setpshared( pthread_barrierattr_t *attr,
                                   int pshared);



int pthread_barrier_destroy( pthread_barrier_t *barrier);
int pthread_barrier_init( pthread_barrier_t *barrier,
                         const pthread_barrierattr_t *attr,
                         unsigned int count);
int pthread_barrier_wait( pthread_barrier_t *barrier);



int pthread_once( pthread_once_t *once_control,
                 void (*init_routine)(void));



int pthread_rwlockattr_init( pthread_rwlockattr_t *attr);
int pthread_rwlockattr_destroy( pthread_rwlockattr_t *attr);
int pthread_rwlockattr_getpshared( const pthread_rwlockattr_t *attr,
                                  int *pshared);
int pthread_rwlockattr_setpshared( pthread_rwlockattr_t *attr,
                                  int pshared);



int pthread_rwlock_destroy( pthread_rwlock_t *rw_lock);
int pthread_rwlock_init( pthread_rwlock_t *rw_lock,
                        const pthread_rwlockattr_t *attr);
int pthread_rwlock_rdlock(pthread_rwlock_t *lock);
int pthread_rwlock_timedrdlock( pthread_rwlock_t *lock,
                               const struct timespec *abstime);
int pthread_rwlock_clockrdlock( pthread_rwlock_t *lock,
                               clockid_t clockid,
                               const struct timespec *abstime);
int pthread_rwlock_tryrdlock( pthread_rwlock_t *lock);
int pthread_rwlock_wrlock( pthread_rwlock_t *lock);
int pthread_rwlock_timedwrlock( pthread_rwlock_t *lock,
                               const struct timespec *abstime);
int pthread_rwlock_clockwrlock( pthread_rwlock_t *lock,
                               clockid_t clockid,
                               const struct timespec *abstime);
int pthread_rwlock_trywrlock( pthread_rwlock_t *lock);
int pthread_rwlock_unlock( pthread_rwlock_t *lock);
# 787 "/tmp/tmpg1w5kvms/nuttx/include/pthread.h" 3 4
int pthread_getcpuclockid(pthread_t thread_id, clockid_t *clock_id);

int pthread_atfork( void (*prepare)(void),
                   void (*parent)(void),
                   void (*child)(void));
# 36 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/userspace.h" 2 3 4
# 32 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 2 3 4



# 1 "/tmp/tmpg1w5kvms/nuttx/include/malloc.h" 1 3 4
# 64 "/tmp/tmpg1w5kvms/nuttx/include/malloc.h" 3 4
struct mallinfo
{
  int arena;

  int ordblks;
  int aordblks;
  int mxordblk;
  int uordblks;

  int fordblks;

  int usmblks;
};

struct malltask
{
  pid_t pid;




};

struct mallinfo_task
{
  int aordblks;
  int uordblks;
};
# 102 "/tmp/tmpg1w5kvms/nuttx/include/malloc.h" 3 4
int mallopt(int param, int value);
struct mallinfo mallinfo(void);
size_t malloc_size( void *ptr);
struct mallinfo_task mallinfo_task( const struct malltask *task);
# 36 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 2 3 4
# 185 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
struct mm_heap_s;

struct mm_heap_config_s
{





  struct mm_heap_s *heap;
  const char *name;
  void *start;
  size_t size;
  _Bool nokasan;
};

struct mempool_init_s
{
  const size_t *poolsize;
  size_t npools;
  size_t threshold;
  size_t chunksize;
  size_t expandsize;
  size_t dict_expendsize;
};
# 254 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
extern struct mm_heap_s *g_mmheap;
# 269 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 struct mm_heap_s *
mm_initialize_heap( const struct mm_heap_config_s *config);

static __attribute__((always_inline)) inline struct mm_heap_s *
mm_initialize( const char *name, void *heapstart, size_t heapsize)
{
  struct mm_heap_config_s config;

  memset(&config, 0, sizeof(config));
  config.name = name;
  config.start = heapstart;
  config.size = heapsize;

  return mm_initialize_heap(&config);
}
# 294 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
void mm_addregion( struct mm_heap_s *heap, void *heapstart,
                  size_t heapsize);
void mm_uninitialize( struct mm_heap_s *heap);



void umm_initialize( void *heap_start, size_t heap_size);
# 310 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
void umm_addregion( void *heapstart, size_t heapsize);
# 320 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 void *mm_malloc( struct mm_heap_s *heap, size_t size) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(2)));
# 330 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
size_t mm_malloc_size( struct mm_heap_s *heap, void *mem);
# 340 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
void mm_free( struct mm_heap_s *heap, void *mem);
# 350 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 void *mm_realloc( struct mm_heap_s *heap, void *oldmem,
                     size_t size) __attribute__((__alloc_size__(3)));
# 361 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 void *mm_calloc( struct mm_heap_s *heap, size_t n,
                    size_t elem_size) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(2, 3)));
# 372 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 void *mm_zalloc( struct mm_heap_s *heap, size_t size) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(2)));
# 388 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 void *mm_memalign( struct mm_heap_s *heap, size_t alignment,
                      size_t size) __attribute__((__malloc__(__builtin_free, 1))) __attribute__((__alloc_size__(3)));
# 399 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
_Bool mm_heapmember( struct mm_heap_s *heap, void *mem);



_Bool umm_heapmember( void *mem);
# 413 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
 void *mm_brkaddr( struct mm_heap_s *heap, int region);



 void *umm_brkaddr(int region);
# 427 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
void mm_extend( struct mm_heap_s *heap, void *mem, size_t size,
               int region);



void umm_extend( void *mem, size_t size, int region);
# 442 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
struct mallinfo mm_mallinfo( struct mm_heap_s *heap);
struct mallinfo_task mm_mallinfo_task( struct mm_heap_s *heap,
                                      const struct malltask *task);

size_t mm_heapfree( struct mm_heap_s *heap);
size_t mm_heapfree_largest( struct mm_heap_s *heap);
# 460 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/mm/mm.h" 3 4
void mm_memdump( struct mm_heap_s *heap,
                const struct malltask *dump);



void umm_memdump( const struct malltask *dump);
# 37 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/kmalloc.h" 2 3 4
# 33 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/lib.h" 2 3 4
# 115 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/lib.h" 3 4
 struct streamlist *lib_get_streams(void);
 struct file_struct *lib_get_stream(int fd);




unsigned long nrand(unsigned long limit);




 char *lib_get_tempbuffer(size_t nbytes);
void lib_put_tempbuffer( char *buffer);
# 138 "/tmp/tmpg1w5kvms/nuttx/include/nuttx/lib/lib.h" 3 4
 char *lib_realpath( const char *path, char *resolved,
                       _Bool notfollow);
# 38 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 2 3 4
# 114 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 3 4
typedef struct file_struct FILE;
# 137 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 3 4
void clearerr( FILE *stream);
void clearerr_unlocked( FILE *stream);
int fclose( FILE *stream);
int fflush( FILE *stream);
int fflush_unlocked( FILE *stream);
int feof( FILE *stream);
int ferror( FILE *stream);
int fileno( FILE *stream);
int fgetc( FILE *stream);
int fgetc_unlocked( FILE *stream);
int fgetpos( FILE *stream, fpos_t *pos);
 char *fgets( char *s, int n, FILE *stream);
 char *fgets_unlocked( char *s, int n, FILE *stream);
 FILE *fopen( const char *path, const char *type) __attribute__((__malloc__(fclose, 1)));
int fprintf( FILE *stream, const char *format, ...)
       __attribute__((__format__(__printf__, 2, 3)));
int fputc(int c, FILE *stream);
int fputc_unlocked(int c, FILE *stream);
int fputs( const char *s, FILE *stream);
int fputs_unlocked( const char *s, FILE *stream);
size_t fread( void *ptr, size_t size, size_t n_items, FILE *stream);
size_t fread_unlocked( void *ptr, size_t size, size_t n_items,
                      FILE *stream);
 FILE *freopen( const char *path, const char *mode,
                  FILE *stream);
int fscanf( FILE *stream, const char *fmt, ...)
       __attribute__((__format__(__scanf__, 2, 3)));
int fseek( FILE *stream, long int offset, int whence);
int fseeko( FILE *stream, off_t offset, int whence);
int fsetpos( FILE *stream, const fpos_t *pos);
long ftell( FILE *stream);
off_t ftello( FILE *stream);
size_t fwrite( const void *ptr, size_t size, size_t n_items,
              FILE *stream);
size_t fwrite_unlocked( const void *ptr, size_t size, size_t n_items,
                       FILE *stream);
int getc( FILE *stream);
int getc_unlocked( FILE *stream);
int getchar(void);
int getchar_unlocked(void);
ssize_t getdelim( char **lineptr, size_t *n, int delimiter,
                 FILE *stream);
ssize_t getline( char **lineptr, size_t *n, FILE *stream);
 char *gets( char *s);
 char *gets_s( char *s, rsize_t n);
void rewind( FILE *stream);

void setbuf( FILE *stream, char *buf);
int setvbuf( FILE *stream, char *buffer, int mode, size_t size);
void setbuffer( FILE *stream, char *buf, size_t size);

int ungetc(int c, FILE *stream);

void flockfile( FILE *stream);
int ftrylockfile( FILE *stream);
void funlockfile( FILE *stream);





void perror( const char *s);
int printf( const char *fmt, ...) __attribute__((__format__(__printf__, 1, 2)));
int putc(int c, FILE *stream);
int putc_unlocked(int c, FILE *stream);
int putchar(int c);
int putchar_unlocked(int c);
int puts( const char *s);
int rename( const char *oldpath, const char *newpath);
int renameat(int olddirfd, const char *oldpath,
                int newdirfd, const char *newpath);
int sprintf( char *buf, const char *fmt, ...)
       __attribute__((__format__(__printf__, 2, 3)));
int asprintf( char **ptr, const char *fmt, ...)
       __attribute__((__format__(__printf__, 2, 3)));
int snprintf( char *buf, size_t size,
                const char *fmt, ...) __attribute__((__format__(__printf__, 3, 4)));
int sscanf( const char *buf, const char *fmt, ...)
       __attribute__((__format__(__scanf__, 2, 3)));

int scanf( const char *fmt, ...) __attribute__((__format__(__scanf__, 1, 2)));
int vasprintf( char **ptr, const char *fmt, va_list ap)
       __attribute__((__format__(__printf__, 2, 0)));
int vfprintf( FILE *stream, const char *fmt,
                va_list ap) __attribute__((__format__(__printf__, 2, 0)));
int vfscanf( FILE *stream, const char *fmt, va_list ap)
       __attribute__((__format__(__scanf__, 2, 0)));
int vprintf( const char *fmt, va_list ap) __attribute__((__format__(__printf__, 1, 0)));
int vscanf( const char *fmt, va_list ap) __attribute__((__format__(__scanf__, 1, 0)));
int vsnprintf( char *buf, size_t size, const char *fmt,
                 va_list ap) __attribute__((__format__(__printf__, 3, 0)));
int vsprintf( char *buf, const char *fmt, va_list ap)
       __attribute__((__format__(__printf__, 2, 0)));
int vsscanf( const char *buf, const char *fmt, va_list ap)
       __attribute__((__format__(__scanf__, 2, 0)));
# 240 "/tmp/tmpg1w5kvms/nuttx/include/stdio.h" 3 4
 FILE *fdopen(int fd, const char *type) __attribute__((__malloc__(fclose, 1)));
int dprintf(int fd, const char *fmt, ...) __attribute__((__format__(__printf__, 2, 3)));
int vdprintf(int fd, const char *fmt, va_list ap)
       __attribute__((__format__(__printf__, 2, 0)));



 FILE *fopencookie( void *cookie, const char *mode,
                      cookie_io_functions_t io_funcs);



 FILE *fmemopen( void *buf, size_t size, const char *mode);
 FILE *open_memstream( char **bufp, size_t *sizep);



 FILE *tmpfile(void) __attribute__((__malloc__(fclose, 1)));
 char *tmpnam( char *s);
 char *tempnam( const char *dir, const char *pfx) __attribute__((__malloc__(__builtin_free, 1)));
int remove( const char *path);






int pclose(FILE *stream);
FILE *popen( const char *command, const char *mode) __attribute__((__malloc__(pclose, 1)));





int nx_asprintf( char **ptr, const char *fmt, ...)
    __attribute__((__format__(__printf__, 2, 3)));
int nx_vasprintf( char **ptr, const char *fmt, va_list ap)
    __attribute__((__format__(__printf__, 2, 0)));
# 38 "/tmp/tmpg1w5kvms/nuttx/include/wchar.h" 2 3 4
# 97 "/tmp/tmpg1w5kvms/nuttx/include/wchar.h" 3 4
struct mbstate_s
{
  int __fill[6];
};

typedef struct mbstate_s mbstate_s;
# 120 "/tmp/tmpg1w5kvms/nuttx/include/wchar.h" 3 4
struct tm;
# 145 "/tmp/tmpg1w5kvms/nuttx/include/wchar.h" 3 4
wint_t btowc(int);
int fwprintf(FILE *, const wchar_t *, ...);
int fwscanf(FILE *, const wchar_t *, ...);
wint_t fgetwc( FILE *);
wint_t fgetwc_unlocked( FILE *f);
 wchar_t *fgetws(wchar_t *, int, FILE *);
wint_t fputwc(wchar_t, FILE *);
wint_t fputwc_unlocked(wchar_t, FILE *);
int fputws( const wchar_t *, FILE *);
int fputws_unlocked( const wchar_t *, FILE *);
int fwide(FILE *, int);
wint_t getwc( FILE *);
wint_t getwchar(void);
int mbsinit( const mbstate_s *);
size_t mbrlen( const char *, size_t, mbstate_s *);
size_t mbrtowc( wchar_t *, const char *, size_t,
                      mbstate_s *);
size_t mbsnrtowcs( wchar_t *, const char **, size_t,
                      size_t, mbstate_s *);
size_t mbsrtowcs( wchar_t *, const char **, size_t,
                      mbstate_s *);
wint_t putwc(wchar_t, FILE *);
wint_t putwc_unlocked(wchar_t, FILE *);
wint_t putwchar(wchar_t);
wint_t putwchar_unlocked(wchar_t);
int swprintf( wchar_t *, size_t, const wchar_t *, ...);
int swscanf( const wchar_t *, const wchar_t *, ...);
wint_t ungetwc(wint_t, FILE *);
wint_t ungetwc_unlocked(wint_t, FILE *);
int vfwprintf(FILE *, const wchar_t *, va_list);
int vfwscanf(FILE *, const wchar_t *, va_list);
int vwprintf( const wchar_t *, va_list);
int vwscanf( const wchar_t *, va_list);
int vswprintf( wchar_t *, size_t, const wchar_t *,
                      va_list);
int vswscanf( const wchar_t *, const wchar_t *,
                      va_list);
size_t wcrtomb( char *, wchar_t, mbstate_s *);
 wchar_t *wcscat( wchar_t *, const wchar_t *);
 wchar_t *wcschr( const wchar_t *, wchar_t);
int wcscmp( const wchar_t *, const wchar_t *);
int wcscoll( const wchar_t *, const wchar_t *);
 wchar_t *wcscpy( wchar_t *, const wchar_t *);
size_t wcscspn( const wchar_t *, const wchar_t *);
size_t wcsftime( wchar_t *, size_t, const wchar_t *,
                      const struct tm *);
size_t wcslen( const wchar_t *);
size_t wcslcpy( wchar_t *, const wchar_t *, size_t);
size_t wcslcat( wchar_t *, const wchar_t *, size_t);
 wchar_t *wcsncat( wchar_t *, const wchar_t *, size_t);
int wcsncmp( const wchar_t *, const wchar_t *, size_t);
 wchar_t *wcsncpy( wchar_t *, const wchar_t *, size_t);
size_t wcsnrtombs( char *, const wchar_t **, size_t,
                      size_t, mbstate_s *);
 wchar_t *wcspbrk( const wchar_t *, const wchar_t *);
 wchar_t *wcsrchr( const wchar_t *, wchar_t);
size_t wcsrtombs( char *, const wchar_t **, size_t,
                      mbstate_s *);
size_t wcsspn( const wchar_t *, const wchar_t *);
 wchar_t *wcsstr( const wchar_t *, const wchar_t *);

double wcstod( const wchar_t *, wchar_t **);


float wcstof( const wchar_t *, wchar_t **);

 wchar_t *wcstok( wchar_t *, const wchar_t *, wchar_t **);
long int wcstol( const wchar_t *, wchar_t **, int);

long double wcstold( const wchar_t *, wchar_t **);

long long int wcstoll( const wchar_t *, wchar_t **, int);
unsigned long int wcstoul( const wchar_t *, wchar_t **, int);
unsigned long long int wcstoull( const wchar_t *, wchar_t **, int);
 wchar_t *wcswcs( const wchar_t *, const wchar_t *);
int wcswidth( const wchar_t *, size_t);
size_t wcsxfrm( wchar_t *, const wchar_t *, size_t);
int wctob(wint_t);
int wcwidth(wchar_t);
 wchar_t *wmemchr( const wchar_t *, wchar_t, size_t);
int wmemcmp( const wchar_t *, const wchar_t *, size_t);
 wchar_t *wmemcpy( wchar_t *, const wchar_t *, size_t);
 wchar_t *wmemmove( wchar_t *, const wchar_t *, size_t);
 wchar_t *wmemset( wchar_t *, wchar_t, size_t);
int wprintf( const wchar_t *, ...);
int wscanf( const wchar_t *, ...);
# 33 "wchar/lib_wcwidth.c" 2






# 38 "wchar/lib_wcwidth.c"
static const unsigned char g_table[] =
{
  16, 16, 16, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 16, 16,
  32, 16, 16, 16, 33, 34, 35, 36, 37, 38, 39, 16, 16, 40, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 41, 42, 16, 16, 43, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 44, 16, 45, 46, 47,
  48, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 49, 16, 16, 50, 51, 16, 52, 16, 16, 16, 16, 16, 16, 16, 16,
  53, 16, 16, 16, 16, 16, 54, 55, 16, 16, 16, 16, 56, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 57, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 58, 59, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 248, 3, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 254, 255, 255, 255, 255, 191, 182, 0, 0, 0, 0, 0, 0, 0, 31, 0, 255,
  7, 0, 0, 0, 0, 0, 248, 255, 255, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  192, 191, 159, 61, 0, 0, 0, 128, 2, 0, 0, 0, 255, 255, 255, 7, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 192, 255, 1, 0, 0, 0, 0, 0, 0, 248, 15, 0, 0, 0, 192,
  251, 239, 62, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 240, 255, 255, 127, 7, 0, 0, 0, 0, 0, 0, 20, 254, 33, 254, 0, 12, 0,
  0, 0, 2, 0, 0, 0, 0, 0, 0, 16, 30, 32, 0, 0, 12, 0, 0, 0, 6, 0, 0, 0, 0,
  0, 0, 16, 134, 57, 2, 0, 0, 0, 35, 0, 6, 0, 0, 0, 0, 0, 0, 16, 190, 33,
  0, 0, 12, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 144, 30, 32, 64, 0, 12, 0, 0, 0,
  4, 0, 0, 0, 0, 0, 0, 0, 1, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 192,
  193, 61, 96, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 144, 64, 48, 0, 0, 12,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 32, 0, 0, 12, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 4, 92, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 242, 7, 128, 127,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 242, 27, 0, 63, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 3, 0, 0, 160, 2, 0, 0, 0, 0, 0, 0, 254, 127, 223, 224, 255, 254,
  255, 255, 255, 31, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 224, 253, 102,
  0, 0, 0, 195, 1, 0, 30, 0, 100, 32, 0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 224, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 0, 0, 0, 28, 0, 0, 0, 12, 0, 0,
  0, 12, 0, 0, 0, 0, 0, 0, 0, 176, 63, 64, 254, 15, 32, 0, 0, 0, 0, 0, 56,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 135, 1, 4, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 1, 0, 0, 0, 0, 0,
  0, 64, 127, 229, 31, 248, 159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 15, 0, 0, 0, 0, 0, 208, 23, 4, 0, 0, 0, 0, 248, 15, 0, 3, 0, 0, 0,
  60, 11, 0, 0, 0, 0, 0, 0, 64, 163, 3, 0, 0, 0, 0, 0, 0, 240, 207, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 247, 255, 253, 33,
  16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 255, 255, 255, 255, 127, 0, 0, 240, 0, 248, 0, 0, 0, 124, 0, 0, 0,
  0, 0, 0, 31, 252, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 128, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0,
  0, 0, 0, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 247, 63,
  0, 0, 0, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 68, 8, 0, 0, 96, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 255, 255,
  3, 0, 0, 0, 0, 0, 192, 63, 0, 0, 128, 255, 3, 0, 0, 0, 0, 0, 7, 0, 0, 0,
  0, 0, 200, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 126, 102, 0, 8, 16,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 157, 193, 2, 0, 0, 0, 0, 48, 64, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 32, 33, 0, 0, 0, 0, 0, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 127,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 110, 240, 0, 0,
  0, 0, 0, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 255, 127, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0,
  0, 0, 0, 120, 38, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 128, 239, 31, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 192, 127, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 191,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 128, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 128, 3, 248, 255, 231, 15, 0, 0, 0, 60, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static const unsigned char g_wtable[] =
{
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 18, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 19, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 20, 21, 22, 23, 24, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 25, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 26, 16, 16, 16, 16, 27, 16,
  16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 28, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 17, 17, 16, 16, 16, 29, 30, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 31, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
  16, 16, 16, 16, 32, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 248, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  252, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  255, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15,
  0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0,
  255, 15, 255, 255, 255, 255, 255, 255, 255, 127, 254, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 224, 255, 255, 255, 255, 63, 254, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 7, 255, 255,
  255, 255, 15, 0, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255,
  0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 255, 255, 255, 255, 255,
  255, 127, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255,
  255, 255, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255,
  255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 15, 0, 255, 255, 127, 248, 255, 255, 255, 255, 255, 15, 0,
  0, 255, 3, 0, 0, 255, 255, 255, 255, 247, 255, 127, 15, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 254, 255, 255, 255, 255, 255, 255, 255,
  255, 255, 255, 255, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 0,
  0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 255, 255, 255, 255, 255, 7, 255, 1, 3, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
# 214 "wchar/lib_wcwidth.c"
int wcwidth(wchar_t wc)
{
  if (wc < 0xffu)
    {
      return ((wc + 1) & 0x7f) >= 0x21 ? 1 : wc ? -1 : 0;
    }

  if ((wc & 0xfffeffffu) < 0xfffe)
    {
      if ((g_table[g_table[wc >> 8] * 32 + ((wc & 255) >> 3)]
          >> (wc & 7)) & 1)
        {
          return 0;
        }

      if ((g_wtable[g_wtable[wc >> 8] * 32 + ((wc & 255) >> 3)]
          >> (wc & 7)) & 1)
        {
          return 2;
        }

      return 1;
    }

  if ((wc & 0xfffe) == 0xfffe)
    {
      return -1;
    }

  if (wc - 0x20000u < 0x20000)
    {
      return 2;
    }

  if (wc - 0xe0020u < 0x5f || wc - 0xe0100 < 0xef)
    {
      return 0;
    }

  return 1;
}
