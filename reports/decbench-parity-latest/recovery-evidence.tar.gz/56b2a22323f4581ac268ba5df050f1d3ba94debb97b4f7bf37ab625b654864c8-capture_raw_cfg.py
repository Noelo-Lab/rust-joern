"""Export unchanged Joern CPG CFG edges, never calling recursive DOT projection."""
import argparse
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

import pyjoern


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--original-dot", action="store_true")
parser.add_argument("--stack")
args = parser.parse_args()
assert version("pyjoern") == "4.0.150.4" and pyjoern.JOERN_VERSION == "v4.0.150"
source = args.source.resolve()
output = args.output.resolve()
metadata = output.with_suffix(output.suffix + ".metadata.json")
assert not output.exists() and not metadata.exists()
output.parent.mkdir(parents=True, exist_ok=True)
script = Path(__file__).with_name("RawCfg.sc").resolve()
installed = Path(pyjoern.__file__).resolve().parent
paths = [installed / "__init__.py", installed / "parsing/fast_parser.py",
         installed / "scala/FastParser.sc", script, Path(__file__).resolve(),
         pyjoern.JOERN_SERVER_PATH]
for directory in (installed / "bin/joern-cli/lib", installed / "bin/joern-cli/frontends/c2cpg/lib"):
    for pattern in ("io.joern.semanticcpg-*.jar", "io.joern.c2cpg-*.jar", "io.joern.eclipse-cdt-core-*.jar", "io.joern.x2cpg-*.jar"):
        paths.extend(directory.glob(pattern))
engines = {str(path): sha(path) for path in paths}
source_hash = sha(source)
environment = dict(os.environ)
environment.pop("PYTHONPATH", None)
previous = environment.get("_JAVA_OPTIONS")
if args.stack:
    environment["_JAVA_OPTIONS"] = ((previous + " ") if previous else "") + "-Xss" + args.stack
command = [str(pyjoern.JOERN_SERVER_PATH), "--script", str(script),
           "--param", "target_dir=" + str(source), "--param", "output=" + str(output),
           "--param", "original_dot=" + str(args.original_dot).lower()]
started = time.perf_counter()
with tempfile.TemporaryDirectory(prefix="rust-joern-raw-cfg-") as cwd:
    result = subprocess.run(command, cwd=cwd, env=environment, text=True,
                            capture_output=True, timeout=600)
elapsed = time.perf_counter() - started
output.with_suffix(output.suffix + ".stdout.txt").write_text(result.stdout)
output.with_suffix(output.suffix + ".stderr.txt").write_text(result.stderr)
assert source_hash == sha(source)
assert engines == {str(path): sha(path) for path in paths}
summary = next((json.loads(line[len("RAW_CFG_EXPORT_SUMMARY "):]) for line in result.stdout.splitlines()
                if line.startswith("RAW_CFG_EXPORT_SUMMARY ")), None)
document = {"schema_version": 1, "generator": "Original PyJoern4.0.150.4/Joernv4.0.150 CPG with read-only raw CFG exporter",
            "source": str(source), "source_sha256": source_hash, "prepared_sha256": source_hash,
            "command": command, "engine_fingerprints": engines, "engine_and_source_unchanged": True,
            "environment_diff": {"previous_JAVA_OPTIONS": previous,
                                 "effective_JAVA_OPTIONS": environment.get("_JAVA_OPTIONS")},
            "raw_export_only": not args.original_dot, "returncode": result.returncode,
            "capture_wall_seconds": elapsed, "export_timing": summary,
            "raw_export": {"path": str(output), "sha256": sha(output)} if output.exists() else None,
            "error": result.stderr if result.returncode else None}
metadata.write_text(json.dumps(document, indent=2) + "\n")
print(json.dumps({"metadata": str(metadata), "returncode": result.returncode,
                  "seconds": elapsed, "summary": summary}, indent=2))
raise SystemExit(result.returncode)
