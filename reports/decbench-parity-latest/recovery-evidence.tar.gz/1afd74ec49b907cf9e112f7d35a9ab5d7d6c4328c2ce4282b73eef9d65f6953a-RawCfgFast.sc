// Read-only original CPG export. No AST/CFG mutation or alternate frontend.
import io.shiftleft.codepropertygraph.generated.PropertyNames
import io.shiftleft.codepropertygraph.generated.nodes.*
import io.shiftleft.semanticcpg.dotgenerator.DotSerializer
import io.shiftleft.semanticcpg.dotgenerator.DotSerializer.Graph
import io.shiftleft.semanticcpg.language.*
import org.apache.commons.text.StringEscapeUtils
import scala.util.Try

def jsonValue(value: Any): String = value match {
  case fields: Map[_, _] => fields.map { case (key, item) =>
    jsonValue(key.toString) + ":" + jsonValue(item)
  }.mkString("{", ",", "}")
  case items: Iterable[_] => items.map(jsonValue).mkString("[", ",", "]")
  case text: String => "\"" + StringEscapeUtils.escapeJson(text) + "\""
  case null => "null"
  case other => other.toString
}

// Exact v4.0.150 CfgGenerator visibility predicate.
def display(node: StoredNode): Boolean = {
  val condition = node match {
    case id: Identifier => id.astParent.isControlStructure
    case _ => false
  }
  condition || !(node.isInstanceOf[Literal] || node.isInstanceOf[Identifier] ||
    node.isInstanceOf[Block] || node.isInstanceOf[ControlStructure] ||
    node.isInstanceOf[JumpTarget] || node.isInstanceOf[MethodParameterIn])
}

@main def exec(target_dir: String, output: String, original_dot: Boolean = false) = {
  val started = System.nanoTime()
  val cpg = importCode(target_dir)
  val imported = System.nanoTime()
  // Preserve original FastParser method selection, duplicate order and last-wins map.
  val names = cpg.method
    .filter(node => node.lineNumber.isDefined && node.lineNumberEnd.isDefined)
    .map(node => (node.fullName, node.filename)).l
  val writer = new java.io.PrintWriter(output, "UTF-8")
  var count = 0
  try {
    names.foreach { case (fullName, filename) =>
      cpg.method.filter(node => node.fullName == fullName && node.filename == filename)
        .filter(node => node.lineNumber.isDefined && node.lineNumberEnd.isDefined && node.body.typeFullName != "<empty>")
        .l.lastOption.foreach { method =>
          val vertices = method.cfgNode.l ++ List(method, method.methodReturn) ++ method.parameter.l
          val unique = vertices.distinct
          val membership = new java.util.HashSet[java.lang.Long]()
          vertices.foreach(node => membership.add(java.lang.Long.valueOf(node.id)))
          val visible = vertices.filter(display)
          val rawNodes = unique.map { node =>
            Map("id" -> node.id, "kind" -> node.label,
              "line" -> node.propertyOption[Int](PropertyNames.LINE_NUMBER).getOrElse(-1),
              "code_prefix" -> node.propertyOption[String](PropertyNames.CODE).getOrElse("").take(120),
              "code_truncated" -> (node.propertyOption[String](PropertyNames.CODE).getOrElse("").length > 120),
              "ast_parent_kind" -> (node match {
                case ast: AstNode => Try(ast.astParent.label).getOrElse("")
                case _ => ""
              }),
              "visible" -> display(node))
          }
          val rawEdges = unique.flatMap { src =>
            src._cfgOut.filter(dst => membership.contains(java.lang.Long.valueOf(dst.id))).map(dst => List(src.id, dst.id)).l
          }
          // Reuse the installed original serializer for every vertex label, including
          // UTF-16 truncation, HTML4 escaping, parent-expression code and newlines.
          val dotNodes = visible.map { node =>
            val text = DotSerializer.dotGraph(None, Graph(List(node), List()))
            Map("id" -> node.id,
              "dot" -> text.substring(text.indexOf('\n') + 1, text.lastIndexOf("\n}\n")))
          }
          val emptyDot = DotSerializer.dotGraph(Some(method), Graph(List(), List()))
          val fields = Map("name" -> method.name, "fullname" -> method.fullName,
            "filename" -> method.filename, "signature" -> method.signature,
            "start_line" -> method.lineNumber.get, "end_line" -> method.lineNumberEnd.get,
            "vertices" -> vertices.map(_.id), "nodes" -> rawNodes, "edges" -> rawEdges,
            "visible_vertices" -> dotNodes,
            "dot_header" -> emptyDot.substring(0, emptyDot.indexOf('\n') + 1),
            "original_dot" -> (if (original_dot) method.dotCfg.l else List()))
          writer.println(jsonValue(fields))
          count += 1
        }
    }
  } finally writer.close()
  val completed = System.nanoTime()
  println("RAW_CFG_EXPORT_SUMMARY " + jsonValue(Map("records" -> count,
    "import_seconds" -> ((imported - started).toDouble / 1e9),
    "raw_export_seconds" -> ((completed - imported).toDouble / 1e9))))
}
