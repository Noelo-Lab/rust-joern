"""Iteratively reproduce v4.0.150 CFG DOT projection, then use original PyJoern."""
import argparse
from collections import defaultdict
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import time

import pyjoern
from pyjoern.parsing.function import Function


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def project(record):
    vertices = set(record["vertices"])
    nodes = {node["id"]: node for node in record["nodes"]}
    assert vertices == set(nodes)
    adjacency = defaultdict(list)
    for src, dst in record["edges"]:
        assert src in vertices and dst in vertices
        adjacency[src].append(dst)
    visible = {node["id"] for node in record["nodes"] if node["visible"]}
    assert visible == {node["id"] for node in record["visible_vertices"]}
    partitions = {}
    for node in vertices:
        children = adjacency[node]
        partitions[node] = ([child for child in children if child in visible],
                            [child for child in children if child not in visible])
    edges = []
    emitted = set()
    max_depth = 0
    for root in record["visible_vertices"]:
        root_id = root["id"]
        active = {root_id}
        stack = []

        def enter(node):
            visible_children, invisible_children = partitions[node]
            for child in visible_children:
                edge = (root_id, child)
                if edge not in emitted:
                    emitted.add(edge)
                    edges.append(edge)
            stack.append((node, iter(invisible_children)))

        enter(root_id)
        while stack:
            max_depth = max(max_depth, len(stack))
            node, children = stack[-1]
            child = next(children, None)
            if child is None:
                stack.pop()
                active.remove(node)
            elif child not in active:
                active.add(child)
                enter(child)
    touched = {node for edge in edges for node in edge}
    vertex_text = [node["dot"] for node in record["visible_vertices"] if node["id"] in touched]
    edge_text = [f'  "{src}" -> "{dst}" ' for src, dst in edges]
    dot = record["dot_header"] + "\n".join(vertex_text + edge_text) + "\n}\n"
    return dot, {"raw_nodes": len(nodes), "raw_edges": len(record["edges"]),
                 "visible_vertices": len(vertex_text), "projected_edges": len(edges),
                 "maximum_invisible_path_depth": max_depth}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--raw", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--require-original-dot", action="store_true")
args = parser.parse_args()
assert version("pyjoern") == "4.0.150.4" and pyjoern.JOERN_VERSION == "v4.0.150"
assert not args.output.exists()
metadata_path = args.raw.with_suffix(args.raw.suffix + ".metadata.json")
metadata = json.loads(metadata_path.read_text())
assert metadata["returncode"] == 0 and metadata["engine_and_source_unchanged"] is True
assert sha(args.raw) == metadata["raw_export"]["sha256"]
records = []
validation = []
started = time.perf_counter()
for index, line in enumerate(args.raw.open()):
    record = json.loads(line)
    dot, statistics = project(record)
    original = record["original_dot"]
    if args.require_original_dot:
        assert len(original) == 1, "Control is missing the genuine original DOT export"
    equal = dot == original[0] if original else None
    assert equal is not False, "Iterative projection differs from genuine DOT for " + record["fullname"]
    validation.append({"index": index, "name": record["name"], "fullname": record["fullname"],
                       "filename": record["filename"], "original_dot_byte_equal": equal, **statistics})
    records.append({key: record[key] for key in ("name", "fullname", "filename", "signature", "start_line", "end_line")}
                   | {"cfg": [dot]})
projected = time.perf_counter()
lifted = Function.from_many(records)
functions = {}
for func in lifted.values():
    graph = func.cfg
    nodes = list(graph)
    mapping = {node: index for index, node in enumerate(nodes)}
    functions[func.name] = {"name": func.name, "start_line": func.start_line, "end_line": func.end_line,
                            "cfg": {"nodes": list(range(len(nodes))),
                                    "edges": [[mapping[src], mapping[dst]] for src, dst in graph.edges],
                                    "entry": [mapping[node] for node in nodes if node.is_entrypoint],
                                    "exit": [mapping[node] for node in nodes if node.is_exitpoint],
                                    "degenerate": not nodes or len(nodes) == 1 and all(type(stmt).__name__ == "Nop" for node in nodes for stmt in node.statements),
                                    "labels": {str(mapping[node]): str(node) for node in nodes}}}
completed = time.perf_counter()
document = {"schema_version": 1,
            "generator": "Original Joernv4.0.150 AST/CFG + iterative exact exporter projection + unchanged PyJoern4.0.150.4 normalization",
            "source_sha256": metadata["source_sha256"], "prepared_sha256": metadata["prepared_sha256"],
            "reference_module": pyjoern.__file__, "raw_export": {"path": str(args.raw.resolve()), "sha256": sha(args.raw)},
            "raw_export_metadata": {"path": str(metadata_path.resolve()), "sha256": sha(metadata_path)},
            "projection_script": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))},
            "projection_source": "v4.0.150 CfgGenerator.edgesToDisplay, explicit stack reproducing visited-path cycle suppression and ordered first-occurrence edge distinct",
            "timings": {"iterative_projection_seconds": projected - started,
                        "original_pyjoern_normalization_seconds": completed - projected},
            "functions": functions, "raw_method_projection": validation,
            "genuine_dot_byte_equal_controls": sum(row["original_dot_byte_equal"] is True for row in validation),
            "genuine_dot_not_requested": sum(row["original_dot_byte_equal"] is None for row in validation),
            "empty_reference": not bool(functions)}
args.output.write_text(json.dumps(document, separators=(",", ":")) + "\n")
print(json.dumps({"output": str(args.output), "functions": len(functions),
                  "raw_methods": len(validation), "genuine_dot_byte_equal_controls": document["genuine_dot_byte_equal_controls"],
                  "max_depth": max((row["maximum_invisible_path_depth"] for row in validation), default=0),
                  "timings": document["timings"]}, indent=2))
